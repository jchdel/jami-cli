import os
import hashlib
import json
from functools import partial
from gi.repository import Gio, GLib, GObject
from loguru import logger
import time

try:
    _
except NameError:
    from gettext import gettext as _

DBUS_DEAMON_OBJECT = 'cx.ring.Ring'
DBUS_DEAMON_PATH = '/cx/ring/Ring'

"""Internal exceptions"""

class CtrlError(Exception):
    """Base class for all our exceptions."""

    def __init__(self, help=None):
        self.help = str(help)

    def __str__(self):
        return self.help

class CtrlDBusError(CtrlError):
    """General error for dbus communication"""

class CtrlDeamonError(CtrlError):
    """General error for daemon communication"""

class CtrlAccountError(CtrlError):
    """General error for account handling"""


class Monitor(GObject.Object):
    """
    Monitors the status of the Jami daemon (singleton).
    """
    __gsignals__ = {
        'daemon-status-changed': (GObject.SignalFlags.RUN_FIRST, None, (str, str)),
    }

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        """Initialize the Jami Monitor (no-op si déjà initialisé)."""
        if getattr(self, '_initialized', False):
            return
        self._initialized = True
        try:
            super().__init__()
            self.connected = False

            try:
                self.bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)

                self.watcher_id = Gio.bus_watch_name(
                    Gio.BusType.SESSION,
                    DBUS_DEAMON_OBJECT,
                    Gio.BusNameWatcherFlags.NONE,
                    self._on_name_appeared,
                    self._on_name_vanished
                )
            except Exception as e:
                logger.error(f"[Monitor] Fatal Init Error: {e}")
                self.emit('daemon-status-changed', 'error', str(e))
        except Exception as e:
            logger.error(f"[Monitor] Init error: {e}")

    def _on_name_appeared(self, connection, name, name_owner):
        """Handle service appearance."""
        try:
            logger.info(f"[Monitor] Service {name} appeared.")
            self.emit('daemon-status-changed', 'connected', 'Ready')
            self.connected = True
        except Exception as e:
            logger.error(f"[Monitor] On name appeared error: {e}")

    def _on_name_vanished(self, connection, name):
        """Handle service disappearance."""
        try:
            logger.warning(f"[Monitor] Service {name} vanished.")
            self.emit('daemon-status-changed', 'offline', 'Jamid service stopped')
            self.connected = False
        except Exception as e:
            logger.error(f"[Monitor] On name vanished error: {e}")
#
# Main class
#

class JamiManager(GObject.Object):
    """
    Manages voice calls and messages via daemon in own thread.

    Singleton : une seule instance partagée par tous les backends.
    Les signaux call-added et call-changed transportent l'account_id
    en premier paramètre pour que chaque backend filtre ses propres appels.
    """
    __gsignals__ = {
        # ── Daemon ────────────────────────────────────────────────────────────
        # Instance.started
        'daemon-started': (GObject.SignalFlags.RUN_FIRST, None, ()),
        # Internal: emitted by _on_daemon_status
        'daemon-connection-status': (GObject.SignalFlags.RUN_FIRST, None, (str, str)),

        # ── Accounts ──────────────────────────────────────────────────────────
        # ConfigurationManager.accountsChanged
        'accounts-changed': (GObject.SignalFlags.RUN_FIRST, None, ()),
        # ConfigurationManager.accountDetailsChanged(accountId, details{ss})
        'account-details-changed': (GObject.SignalFlags.RUN_FIRST, None, (str, object)),
        # ConfigurationManager.registrationStateChanged(accountId, state, code, codeStr)
        'registration-state-changed': (GObject.SignalFlags.RUN_FIRST, None, (str, str, int, str)),
        # ConfigurationManager.volatileAccountDetailsChanged(accountId, details{ss})
        'volatile-account-details-changed': (GObject.SignalFlags.RUN_FIRST, None, (str, object)),
        # ConfigurationManager.accountProfileReceived(accountId, displayName, photo)
        'account-profile-received': (GObject.SignalFlags.RUN_FIRST, None, (str, str, str)),
        # ConfigurationManager.knownDevicesChanged(accountId, devices{ss})
        'known-devices-changed': (GObject.SignalFlags.RUN_FIRST, None, (str, object)),
        # ConfigurationManager.deviceAuthStateChanged(accountId, state, detail{ss})
        'device-auth-state-changed': (GObject.SignalFlags.RUN_FIRST, None, (str, int, object)),
        # ConfigurationManager.addDeviceStateChanged(accountId, op_id, state, detail{ss})
        'add-device-state-changed': (GObject.SignalFlags.RUN_FIRST, None, (str, int, int, object)),
        # ConfigurationManager.deviceRevocationEnded(accountId, deviceId, status)
        #   status: 0=SUCCESS 1=WRONG_PASSWORD 2=UNKNOWN_DEVICE
        'device-revocation-ended': (GObject.SignalFlags.RUN_FIRST, None, (str, str, int)),
        # ConfigurationManager.stunStatusFailure(reason)
        'stun-status-failure': (GObject.SignalFlags.RUN_FIRST, None, (str,)),
        # ConfigurationManager.errorAlert(code)
        'error-alert': (GObject.SignalFlags.RUN_FIRST, None, (int,)),
        # ConfigurationManager.migrationEnded(accountId, result) result: SUCCESS|INVALID
        'migration-ended': (GObject.SignalFlags.RUN_FIRST, None, (str, str)),
        # ConfigurationManager.mediaParametersChanged(accountId)
        'media-parameters-changed': (GObject.SignalFlags.RUN_FIRST, None, (str,)),
        # ConfigurationManager.registeredNameFound(accountId, requestName, status, address, name)
        #   status: 0=SUCCESS 1=INVALID_NAME 2=NOT_FOUND 3=ERROR
        'registered-name-found': (GObject.SignalFlags.RUN_FIRST, None, (str, str, int, str, str)),
        # ConfigurationManager.nameRegistrationEnded(accountId, status, name)
        #   status: 0=SUCCESS 1=WRONG_PASSWORD 2=INVALID_NAME 3=ALREADY_TAKEN 4=NETWORK_ERROR
        'name-registration-ended': (GObject.SignalFlags.RUN_FIRST, None, (str, int, str)),
        # ConfigurationManager.userSearchEnded(accountId, status, query, result[{ss}])
        'user-search-ended': (GObject.SignalFlags.RUN_FIRST, None, (str, int, str, object)),
        # ConfigurationManager.debugMessageReceived(message)
        'debug-message-received': (GObject.SignalFlags.RUN_FIRST, None, (str,)),
        # ConfigurationManager.messageSend(message) — daemon log line
        'message-send': (GObject.SignalFlags.RUN_FIRST, None, (str,)),

        # ── Contacts ──────────────────────────────────────────────────────────
        # ConfigurationManager.contactAdded(accountId, uri, confirmed)
        'contact-added': (GObject.SignalFlags.RUN_FIRST, None, (str,)),
        # ConfigurationManager.contactRemoved(accountId, uri, banned)
        'contact-removed': (GObject.SignalFlags.RUN_FIRST, None, (str, str, int)),
        # ConfigurationManager.profileReceived(accountId, from, path)
        'profile-received': (GObject.SignalFlags.RUN_FIRST, None, (str, str, str)),
        # ConfigurationManager.incomingTrustRequest(accountId, conversationId, from, payload, receiveTime)
        'trust-request': (GObject.SignalFlags.RUN_FIRST, None, (str, str, str, str, int)),

        # ── Calls ─────────────────────────────────────────────────────────────
        # Internal: synthesised from incomingCall / incomingCallWithMedia
        'call-added': (GObject.SignalFlags.RUN_FIRST, None, (str, str, object)),
        # Internal: emitted by placeCall / placeCallWithMedia
        'call-started': (GObject.SignalFlags.RUN_FIRST, None, (str, object)),
        # Internal: emitted when call state reaches OVER
        'call-removed': (GObject.SignalFlags.RUN_FIRST, None, (str,)),
        # Internal: emitted on every non-OVER callStateChanged
        'call-changed': (GObject.SignalFlags.RUN_FIRST, None, (str, str, str)),
        # Internal: synthesised from BUSY state
        'call-missed': (GObject.SignalFlags.RUN_FIRST, None, (str,)),
        # Internal: synthesised from HUNGUP+code 103
        'call-refused': (GObject.SignalFlags.RUN_FIRST, None, (str,)),
        # Internal: synthesised from HUNGUP after CURRENT
        'call-hangup': (GObject.SignalFlags.RUN_FIRST, None, (str, int,)),
        # CallManager.incomingMessage(accountId, callId, from, messages{ss})
        'incoming-call-message': (GObject.SignalFlags.RUN_FIRST, None, (str, str, str, object)),
        # CallManager.mediaChangeRequested(accountId, callId, mediaList[{ss}])
        'media-change-requested': (GObject.SignalFlags.RUN_FIRST, None, (str, str, object)),
        # CallManager.mediaNegotiationStatus(callId, event, mediaList[{ss}])
        #   event: NEGOTIATION_SUCCESS | NEGOTIATION_FAIL
        'media-negotiation-status': (GObject.SignalFlags.RUN_FIRST, None, (str, str, str, object)),
        # CallManager.peerHold(callId, peerHold)
        'peer-hold': (GObject.SignalFlags.RUN_FIRST, None, (str, int)),
        # CallManager.audioMuted(callId, audioMuted)
        'audio-muted': (GObject.SignalFlags.RUN_FIRST, None, (str, int)),
        # CallManager.videoMuted(callId, videoMuted)
        'video-muted': (GObject.SignalFlags.RUN_FIRST, None, (str, int)),
        # CallManager.transferSucceeded — call is no longer accessible in daemon
        'transfer-succeeded': (GObject.SignalFlags.RUN_FIRST, None, ()),
        # CallManager.transferFailed — call is no longer accessible in daemon
        'transfer-failed': (GObject.SignalFlags.RUN_FIRST, None, ()),

        # ── Recording ─────────────────────────────────────────────────────────
        # CallManager.recordPlaybackFilepath(callId, filepath)
        'record-playback-filepath': (GObject.SignalFlags.RUN_FIRST, None, (str, str)),
        # CallManager.recordPlaybackStopped(filepath)
        'record-playback-stopped': (GObject.SignalFlags.RUN_FIRST, None, (str,)),
        # CallManager.updatePlaybackScale(filepath, position, size)
        'update-playback-scale': (GObject.SignalFlags.RUN_FIRST, None, (str, int, int)),
        # CallManager.recordingStateChanged(callId, recordingState)
        'recording-state-changed': (GObject.SignalFlags.RUN_FIRST, None, (str, int)),
        # CallManager.remoteRecordingChanged(callId, peerNumber, remoteRecordingState)
        'remote-recording-changed': (GObject.SignalFlags.RUN_FIRST, None, (str, str, int)),
        # CallManager.onRtcpReportReceived(callId, report{si})
        #   report keys: PACKET_LOSS CUMULATIVE_LOSS ROUND_TRIP_DELAY LATENCY
        'rtcp-report-received': (GObject.SignalFlags.RUN_FIRST, None, (str, object)),

        # ── Conferences ───────────────────────────────────────────────────────
        # CallManager.conferenceCreated(accountId, conversationId, confId)
        'conference-created': (GObject.SignalFlags.RUN_FIRST, None, (str, str, str)),
        # CallManager.conferenceChanged(accountId, confId, state)
        #   state: ACTIVE_ATTACHED | ACTIVE_DETACHED | HOLD
        'conference-changed': (GObject.SignalFlags.RUN_FIRST, None, (str, str, str)),
        # CallManager.conferenceRemoved(accountId, confId)
        'conference-removed': (GObject.SignalFlags.RUN_FIRST, None, (str, str)),
        # CallManager.onConferenceInfosUpdated(confId, infos[{ss}])
        'conference-infos-updated': (GObject.SignalFlags.RUN_FIRST, None, (str, object)),

        # ── Messaging ─────────────────────────────────────────────────────────
        # ConfigurationManager.incomingAccountMessage(accountId, messageID, from, payloads{ss})
        'account-message-received': (GObject.SignalFlags.RUN_FIRST, None, (str, str, object,)),
        # Internal: synthesised from accountMessageStatusChanged status=1
        'account-message-sent': (GObject.SignalFlags.RUN_FIRST, None, (str,)),
        # Internal: synthesised from accountMessageStatusChanged status=2
        'account-message-read': (GObject.SignalFlags.RUN_FIRST, None, (str,)),
        # CallManager.voiceMailNotify(accountId, newCount, oldCount, urgentCount)
        'voice-mail-notify': (GObject.SignalFlags.RUN_FIRST, None, (str, int, int, int)),
        # ConfigurationManager.composingStatusChanged(accountId, conversationId, contactId, status)
        #   status: 0=Idle 1=Active
        'composing-status-changed': (GObject.SignalFlags.RUN_FIRST, None, (str, str, str, int)),

        # ── Conversations (swarm) ─────────────────────────────────────────────
        # ConfigurationManager.conversationReady(accountId, conversationId)
        'conversation-ready': (GObject.SignalFlags.RUN_FIRST, None, (str, str)),
        # ConfigurationManager.conversationRemoved(accountId, conversationId)
        'conversation-removed': (GObject.SignalFlags.RUN_FIRST, None, (str, str)),
        # ConfigurationManager.conversationRequestReceived(accountId, conversationId, metadatas{ss})
        'conversation-request-received': (GObject.SignalFlags.RUN_FIRST, None, (str, str, object)),
        # ConfigurationManager.conversationRequestDeclined(accountId, conversationId)
        'conversation-request-declined': (GObject.SignalFlags.RUN_FIRST, None, (str, str)),
        # ConfigurationManager.conversationMemberEvent(accountId, conversationId, memberUri, event)
        #   event: 0=add 1=joins 2=leave 3=banned
        'conversation-member-event': (GObject.SignalFlags.RUN_FIRST, None, (str, str, str, int)),
        # ConfigurationManager.onConversationError(accountId, conversationId, code, what)
        'conversation-error': (GObject.SignalFlags.RUN_FIRST, None, (str, str, int, str)),
        # ConfigurationManager.conversationProfileUpdated(accountId, conversationId, profile{ss})
        'conversation-profile-updated': (GObject.SignalFlags.RUN_FIRST, None, (str, str, object)),
        # ConfigurationManager.conversationPreferencesUpdated(accountId, conversationId, preferences{ss})
        'conversation-preferences-updated': (GObject.SignalFlags.RUN_FIRST, None, (str, str, object)),
        # ConfigurationManager.messageReceived / swarm variant (non-documented)
        'conversation-message-received': (GObject.SignalFlags.RUN_FIRST, None, (str, str, object)),
        # ConfigurationManager.needsHost(accountId, conversationId)
        'needs-host': (GObject.SignalFlags.RUN_FIRST, None, (str, str)),
        # ConfigurationManager.activeCallsChanged(accountId, conversationId, activeCalls[{ss}])
        'active-calls-changed': (GObject.SignalFlags.RUN_FIRST, None, (str, str, object)),

        # ── Swarm messages ────────────────────────────────────────────────────
        # ConfigurationManager.swarmMessageReceived(accountId, conversationId, message)
        'swarm-message-received': (GObject.SignalFlags.RUN_FIRST, None, (str, str, object)),
        # ConfigurationManager.swarmMessageUpdated(accountId, conversationId, message)
        'swarm-message-updated': (GObject.SignalFlags.RUN_FIRST, None, (str, str, object)),
        # ConfigurationManager.swarmLoaded(id, accountId, conversationId, messages)
        'swarm-loaded': (GObject.SignalFlags.RUN_FIRST, None, (int, str, str, object)),
        # ConfigurationManager.messagesFound(id, accountId, conversationId, messages[{ss}])
        'messages-found': (GObject.SignalFlags.RUN_FIRST, None, (int, str, str, object)),
        # ConfigurationManager.reactionAdded(accountId, conversationId, messageId, reaction{ss})
        'reaction-added': (GObject.SignalFlags.RUN_FIRST, None, (str, str, str, object)),
        # ConfigurationManager.reactionRemoved(accountId, conversationId, messageId, reactionId)
        'reaction-removed': (GObject.SignalFlags.RUN_FIRST, None, (str, str, str, str)),

        # ── File transfers ────────────────────────────────────────────────────
        # ConfigurationManager.dataTransferEvent(accountId, conversationId, interactionId, fileId, code)
        'data-transfer-event': (GObject.SignalFlags.RUN_FIRST, None, (str, str, str, str, int)),

        # ── Certificates ─────────────────────────────────────────────────────
        # ConfigurationManager.certificateStateChanged(accountId, certId, state)
        'certificate-state-changed': (GObject.SignalFlags.RUN_FIRST, None, (str, str, str)),
        # ConfigurationManager.certificatePinned(certId)
        'certificate-pinned': (GObject.SignalFlags.RUN_FIRST, None, (str,)),
        # ConfigurationManager.certificatePathPinned(path, certIds[s])
        'certificate-path-pinned': (GObject.SignalFlags.RUN_FIRST, None, (str, object)),
        # ConfigurationManager.certificateExpired(certId)
        'certificate-expired': (GObject.SignalFlags.RUN_FIRST, None, (str,)),

        # ── Audio ─────────────────────────────────────────────────────────────
        # ConfigurationManager.volumeChanged(device, value) — ALSA only
        'volume-changed': (GObject.SignalFlags.RUN_FIRST, None, (str, float)),
        # ConfigurationManager.hardwareDecodingChanged(state)
        'hardware-decoding-changed': (GObject.SignalFlags.RUN_FIRST, None, (int,)),
        # ConfigurationManager.hardwareEncodingChanged(state)
        'hardware-encoding-changed': (GObject.SignalFlags.RUN_FIRST, None, (int,)),
        # ConfigurationManager.audioDeviceEvent — headset plug/unplug etc.
        'audio-device-event': (GObject.SignalFlags.RUN_FIRST, None, ()),
        # ConfigurationManager.audioMeter(id, level) — RMS 0..1, high frequency
        'audio-meter': (GObject.SignalFlags.RUN_FIRST, None, (str, float)),

        # ── Presence ─────────────────────────────────────────────────────────
        # Internal: synthesised from newBuddyNotification / nearbyPeerNotification
        #           / subscriptionStateChanged
        'presence-changed': (GObject.SignalFlags.RUN_FIRST, None, (str, int)),
        # PresenceManager.newServerSubscriptionRequest(buddyUri)
        'new-server-subscription-request': (GObject.SignalFlags.RUN_FIRST, None, (str,)),
        # PresenceManager.serverError(accountId, error, msg)
        'server-error': (GObject.SignalFlags.RUN_FIRST, None, (str, str, str)),

        # ── Video ─────────────────────────────────────────────────────────────
        # VideoManager.deviceEvent — v4l2 device plug/unplug
        'device-event': (GObject.SignalFlags.RUN_FIRST, None, ()),
        # VideoManager.decodingStarted(id, shmPath, width, height, isMixer)
        'decoding-started': (GObject.SignalFlags.RUN_FIRST, None, (str, str, int, int, int)),
        # VideoManager.decodingStopped(id, shmPath, isMixer)
        'decoding-stopped': (GObject.SignalFlags.RUN_FIRST, None, (str, str, int)),
        # VideoManager.fileOpened(playerId, info{ss})
        'file-opened': (GObject.SignalFlags.RUN_FIRST, None, (str, object)),

        # ── Plugins ───────────────────────────────────────────────────────────
        # PluginManagerInterface.webViewMessageReceived(pluginId, webViewId, messageId, payload)
        'web-view-message-received': (GObject.SignalFlags.RUN_FIRST, None, (str, str, str, str)),
    }

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        """Initialize the daemon manager (no-op si déjà initialisé)."""
        if getattr(self, '_initialized', False):
            return
        self._initialized = True
        try:
            super().__init__()

            # internals
            self.name = "What.The.Fog" # client name
            self.registered = False
            self.bus = None
            self._last_daemon_status = None
            self.proxy_instance = None
            self.proxy_callmgr = None
            self.proxy_confmgr = None
            self.proxy_videomgr = None
            self.proxy_presmgr = None
            self.proxy_plugins = None

            # to know when daemon is present
            self.daemon_monitor = Monitor()
            self.daemon_monitor.connect('daemon-status-changed', self._on_daemon_status)

            # application state 
            self.activeCalls = {}  # list of active calls (known by the client)
            self.activeConferences = {}  # list of active conferences
            self.account = None  # current active account
            self.autoAnswer = False

            self.contacts = {} # k=name, v=uri
            self.cachedContactsList = {} # k=uri, v=details[]
            self.stcatnoc = {} # k=uri, v=name
            self.buddyUriList = {}  # list of buddy URI list: k=uri, v=presence
            self.buddyUriTimers = {}  # list of buddy URI list: k=uri, v=timer_id
            self.invalidBuddyUris = []  # list of forbidden buddy URI

            self.currentCallId = None
            self.currentConfId = None

            # for automatic trust negotiation
            self.trust_initiator = False
            self.wait_for_trust = False
            self.tmpcode = ""

        except Exception as e:
            logger.error(f"[Manager] Init error: {e}")

    ####################################################################
    # Signal dispatchers
    ####################################################################

    def on_instance_signal(self, proxy, sender, signal, params):
        """Complete; only one signal: Instance.started."""
        params = params.unpack()
        if not signal:
            pass
        elif signal == "started":
            self.emit('daemon-started')
        else:
            logger.warning(f"[Instance] Unexpected signal '{signal}' received")

    def on_callmgr_signal(self, proxy, sender, signal, params):
        """ complete """
        params = params.unpack()
        if not signal:
            pass
        elif signal == "recordPlaybackFilepath":
            self.on_recordPlaybackFilepath(*params)
        elif signal == "recordPlaybackStopped":
            self.on_recordPlaybackStopped(*params)
        elif signal == "updatePlaybackScale":
            self.on_updatePlaybackScale(*params)
        elif signal == "incomingCall":
            self.on_incomingCall(*params)
        elif signal == "mediaChangeRequested":
            self.on_mediaChangeRequested(*params)
        elif signal == "incomingMessage":
            self.on_incomingMessage(*params)
        elif signal == "callStateChanged":
            self.on_callStateChanged(*params)
        elif signal == "conferenceChanged":
            self.on_conferenceChanged(*params)
        elif signal == "conferenceCreated":
            self.on_conferenceCreated(*params)
        elif signal == "conferenceRemoved":
            self.on_conferenceRemoved(*params)
        elif signal == "voiceMailNotify":
            self.on_voiceMailNotify(*params)
        elif signal == "transferSucceeded":
            self.on_transferSucceeded(*params)
        elif signal == "transferFailed":
            self.on_transferFailed(*params)
        elif signal == "recordingStateChange":
            self.on_recordingStateChange(*params)
        elif signal == "onRtcpReportReceived":
            self.on_onRtcpReportReceived(*params)
        elif signal == "peerHold":
            self.on_peerHold(*params)
        elif signal == "audioMuted":
            self.on_audioMuted(*params)
        elif signal == "videoMuted":
            self.on_videoMuted(*params)
        elif signal == "onConferenceInfosUpdated":
            self.on_onConferenceInfosUpdated(*params)
        elif signal == "remoteRecordingChanged":
            self.on_remoteRecordingChanged(*params)
        elif signal == "mediaNegotiationStatus":
            self.on_mediaNegotiationStatus(*params)
        # added as seen in the wild even if not documented
        elif signal == "incomingCallWithMedia":
            self.on_incomingCallWithMedia(*params)
        else:
            logger.warning(f"[CallManager] Unexpected signal '{signal}' received")

    def on_confmgr_signal(self, proxy, sender, signal, params):
        """ complete """
        params = params.unpack()
        if signal == "deviceAuthStateChanged":
            self.on_deviceAuthStateChanged(*params)
        elif signal == "addDeviceStateChanged":
            self.on_addDeviceStateChanged(*params)
        elif signal == "deviceRevocationEnded":
            self.on_deviceRevocationEnded(*params)
        elif signal == "accountProfileReceived":
            self.on_accountProfileReceived(*params)
        elif signal == "knownDevicesChanged":
            self.on_knownDevicesChanged(*params)
        elif signal == "registeredNameFound":
            self.on_registeredNameFound(*params)
        elif signal == "nameRegistrationEnded":
            self.on_nameRegistrationEnded(*params)
        elif signal == "userSearchEnded":
            self.on_userSearchEnded(*params)
        elif signal == "incomingAccountMessage":
            self.on_incomingAccountMessage(*params)
        elif signal == "accountMessageStatusChanged":
            self.on_accountMessageStatusChanged(*params)
        elif signal == "needsHost":
            self.on_needsHost(*params)
        elif signal == "activeCallsChanged":
            self.on_activeCallsChanged(*params)
        elif signal == "profileReceived":
            self.on_profileReceived(*params)
        elif signal == "composingStatusChanged":
            self.on_composingStatusChanged(*params)
        elif signal == "volumeChanged":
            self.on_volumeChanged(*params)
        elif signal == "hardwareDecodingChanged":
            self.on_hardwareDecodingChanged(*params)
        elif signal == "hardwareEncodingChanged":
            self.on_hardwareEncodingChanged(*params)
        elif signal == "audioDeviceEvent":
            self.on_audioDeviceEvent(*params)
        elif signal == "audioMeter":
            self.on_audioMeter(*params)
        elif signal == "accountsChanged":
            self.on_accountsChanged(*params)
        elif signal == "accountDetailsChanged":
            self.on_accountDetailsChanged(*params)
        elif signal == "registrationStateChanged":
            self.on_registrationStateChanged(*params)
        elif signal == "volatileAccountDetailsChanged":
            self.on_volatileAccountDetailsChanged(*params)
        elif signal == "stunStatusFailure":
            self.on_stunStatusFailure(*params)
        elif signal == "errorAlert":
            self.on_errorAlert(*params)
        elif signal == "certificateStateChanged":
            self.on_certificateStateChanged(*params)
        elif signal == "certificatePinned":
            self.on_certificatePinned(*params)
        elif signal == "certificatePathPinned":
            self.on_certificatePathPinned(*params)
        elif signal == "certificateExpired":
            self.on_certificateExpired(*params)
        elif signal == "incomingTrustRequest":
            self.on_incomingTrustRequest(*params)
        elif signal == "contactAdded":
            self.on_contactAdded(*params)
        elif signal == "contactRemoved":
            self.on_contactRemoved(*params)
        elif signal == "mediaParametersChanged":
            self.on_mediaParametersChanged(*params)
        elif signal == "migrationEnded":
            self.on_migrationEnded(*params)
        elif signal == "dataTransferEvent":
            self.on_dataTransferEvent(*params)
        elif signal == "swarmLoaded":
            self.on_swarmLoaded(*params)
        elif signal == "messagesFound":
            self.on_messagesFound(*params)
        elif signal == "swarmMessageReceived":
            self.on_swarmMessageReceived(*params)
        elif signal == "swarmMessageUpdated":
            self.on_swarmMessageUpdated(*params)
        elif signal == "reactionAdded":
            self.on_reactionAdded(*params)
        elif signal == "reactionRemoved":
            self.on_reactionRemoved(*params)
        elif signal == "conversationProfileUpdated":
            self.on_conversationProfileUpdated(*params)
        elif signal == "conversationRequestReceived":
            self.on_conversationRequestReceived(*params)
        elif signal == "conversationRequestDeclined":
            self.on_conversationRequestDeclined(*params)
        elif signal == "conversationReady":
            self.on_conversationReady(*params)
        elif signal == "conversationRemoved":
            self.on_conversationRemoved(*params)
        elif signal == "conversationMemberEvent":
            self.on_conversationMemberEvent(*params)
        elif signal == "onConversationError":
            self.on_onConversationError(*params)
        elif signal == "conversationPreferencesUpdated":
            self.on_conversationPreferencesUpdated(*params)
        elif signal == "debugMessageReceived":
            self.on_debugMessageReceived(*params)
        elif signal == "messageSend":
            self.on_messageSend(*params)
        # added after observing the signal in the wild even if it is not documented
        elif signal == "messageReceived":
            self.on_messageReceived(*params)
        else:
            logger.warning(f"[ConfigurationManager] Unexpected signal '{signal}' received")


    def on_videomgr_signal(self, proxy, sender, signal, params):
        """ complete; there are 4 signals! """
        params = params.unpack()
        if signal == None:
            pass
        elif signal == "deviceEvent":
            self.on_deviceEvent(*params)
        elif signal == "decodingStarted":
            self.on_decodingStarted(*params)
        elif signal == "decodingStopped":
            self.on_decodingStopped(*params)
        elif signal == "fileOpened":
            self.on_fileOpened(*params)
        else:
            logger.warning(f"[VideoManager] Unexpected signal '{signal}' received")


    def on_presmgr_signal(self, proxy, sender, signal, params):
        """ complete; there are 4 signals! """
        params = params.unpack()
        if not signal:
            pass
        elif signal == "newBuddyNotification":
            self.on_newBuddyNotification(*params)
        elif signal == "nearbyPeerNotification":
            self.on_nearbyPeerNotification(*params)
        elif signal == "subscriptionStateChanged":
            self.on_subscriptionStateChanged(*params)
        elif signal == "newServerSubscriptionRequest":
            self.on_newServerSubscriptionRequest(*params)
        elif signal == "serverError":
            self.on_serverError(*params)
        else:
            logger.warning(f"[PresenceManager] Unexpected signal '{signal}' received")

    def on_plugins_signal(self, proxy, sender, signal, params):
        """ complete; there is only a single signal! """
        params = params.unpack()
        if not signal:
            pass
        elif signal == "webViewMessageReceived":
            self.on_webViewMessageReceived(*params)
        else:
            logger.warning(f"[Plugins] Unexpected signal '{signal}' received")


    #
    # Signal handling callbacks
    #

    #
    # CallManager
    #

    def onConferenceCreated_cb(self):
        pass

    def onConferenceCreated_callback(self, convId, confId):
        pass

    #
    # PresenceManager
    #

    def onContactAdded_cb(self, account, uri, confirmed):
        self.emit('contact-added', uri)

    def _erode_presence(self, buddyUri):
        self.buddyUriList[buddyUri] -= 1
        self.emit('presence-changed', buddyUri, self.buddyUriList[buddyUri])
        return False # redo

    def onSubscriptionStateChanged_cb(self, accountId, buddyUri, state):
        #if buddyUri in self.buddyUriTimers:
        #    GLib.source_remove(self.buddyUriTimers[buddyUri])
        #    del self.buddyUriTimers[buddyUri]
        self.emit('presence-changed', buddyUri, state)
        #self.buddyUriTimers[buddyUri] = GLib.timeout_add(600000, self._erode_presence, buddyUri)

    def onNewServerSubscriptionRequest_cb(self, buddyUri):
        # you should accept with self.subscribeBuddy(buddyUri, True)
        pass

    #
    # Trust management
    #

    def onIncomingTrustRequest_cb(self, account, conversation, orig, payload, received):
        """ payload is a bytearray """
        payload = bytearray(payload).decode('utf_8')
        self.emit("trust-request", account, conversation, orig, payload, int(received))

    #
    # Signal handling
    #

    #
    # CallManager
    #

    def on_recordPlaybackFilepath(self, callId, filepath):
        """Emitted once when a recording starts, providing the recorded file path."""
        self.emit('record-playback-filepath', callId, filepath)

    def on_recordPlaybackStopped(self, filepath):
        """Emitted when record playback has stopped."""
        self.emit('record-playback-stopped', filepath)

    def on_updatePlaybackScale(self, filepath, position, size):
        """Emitted to update the playback position on a linear scale."""
        self.emit('update-playback-scale', filepath, position, size)

    def on_incomingCall(self, account, callId, peer, *extra):
        if callId not in self.activeCalls:
            self.activeCalls[callId] = self.getCallDetails(account=account, callId=callId) or {}
        self.activeCalls[callId]['PEER_NUMBER'] = peer
        self.activeCalls[callId]['CALL_STATE'] = 'INCOMING'
        self.activeCalls[callId]['ACCOUNT_ID'] = account
        self.emit('call-added', account, callId, self.activeCalls[callId])

    def on_incomingCallWithMedia(self, account, callId, peer, media=None):
        if callId not in self.activeCalls:
            self.activeCalls[callId] = self.getCallDetails(account=account, callId=callId) or {}
        self.activeCalls[callId]['PEER_NUMBER'] = peer
        self.activeCalls[callId]['CALL_STATE'] = 'INCOMING'
        self.activeCalls[callId]['ACCOUNT_ID'] = account
        self.emit('call-added', account, callId, self.activeCalls[callId])

    def on_mediaChangeRequested(self, accountId, callId, mediaList):
        """Emitted when a media change request is received from the peer.

        The client can control the attributes of the media in the answer.
        """
        self.emit('media-change-requested', accountId, callId, mediaList)

    def on_incomingMessage(self, accountId, callId, from_, messages):
        """Emitted when new in-call text messages are received.

        messages is a dict of mime-type → payload.
        """
        self.emit('incoming-call-message', accountId, callId, from_, messages)

    def on_callStateChanged(self, account, callId, state, code):
        """ On call state changed event, set the values for new calls,
        or delete the call from the list of active calls
        """
        callDetails = self.getCallDetails(account=account, callId=callId) or {}
        if callId in self.activeCalls.keys():
            for k,v in callDetails.items():
                 self.activeCalls[callId][k] = v
        else:
            self.activeCalls[callId] = callDetails
        self.activeCalls[callId]['state'] = state
        self.activeCalls[callId]['CALL_STATE'] = state
        self.activeCalls[callId]['ACCOUNT_ID'] = account

        if state == "INACTIVE": 
            pass
        elif state == "CONNECTING":
            pass
        elif state == "RINGING":
            pass
        elif state == "INCOMING":
            pass
        elif state == "CURRENT":
            self.currentCallId = callId
            if 'start' not in self.activeCalls[callId]:
                self.activeCalls[callId]['start'] = time.time()
        elif state == "HOLD":
            pass
        elif state == "BUSY":
            self.emit('call-missed', self.activeCalls[callId]['PEER_NUMBER'])
        elif state == "FAILURE":
            pass
        elif state == "HUNGUP": 
            if 'start' in self.activeCalls[callId]:
                diff = int(time.time() - self.activeCalls[callId]['start'])
                self.emit('call-hangup', callId, diff)
            elif int(code) == 103:
                state = "REFUSED"
                self.emit('call-refused', self.activeCalls[callId]['PEER_NUMBER'])
        elif state == "OVER":
            del self.activeCalls[callId]
            if callId == self.currentCallId:
                self.currentCallId = None
            self.emit('call-removed', callId)
        else:
            logger.warning("unknown state:" + str(state))

        if state != 'OVER':
            self.emit('call-changed', account, callId, state)

    def on_conferenceChanged(self, accountId, confId, state):
        """Emitted on a conference state change.

        state: ACTIVE_ATTACHED | ACTIVE_DETACHED | HOLD
        """
        self.emit('conference-changed', accountId, confId, state)

    def on_conferenceCreated(self, accountId, conversationId, confId):
        """Emitted when a new conference is created.

        Client should call getParticipantList to update the display.
        """
        self.currentConfId = confId
        self.onConferenceCreated_cb()
        self.onConferenceCreated_callback(conversationId, confId)
        self.emit('conference-created', accountId, conversationId, confId)

    def on_conferenceRemoved(self, accountId, confId):
        """Emitted when a conference is removed."""
        self.emit('conference-removed', accountId, confId)

    def on_voiceMailNotify(self, accountId, newCount, oldCount, urgentCount):
        """Emitted to notify the client of the voicemail count for an account."""
        self.emit('voice-mail-notify', accountId, newCount, oldCount, urgentCount)

    def on_transferSucceeded(self):
        """Emitted when a call transfer was successfully processed.

        The transferred call is no longer accessible in the daemon.
        """
        self.emit('transfer-succeeded')

    def on_transferFailed(self):
        """Emitted when a call transfer operation failed.

        The corresponding call is no longer accessible in the daemon.
        """
        self.emit('transfer-failed')

    def on_recordingStateChange(self, callId, recordingState):
        """Emitted when the recording state of a call changes."""
        self.emit('recording-state-changed', callId, int(recordingState))

    def on_onRtcpReportReceived(self, callId, report):
        """Emitted after an RTCP report has been received and computed.

        report keys: PACKET_LOSS, CUMULATIVE_LOSS, ROUND_TRIP_DELAY, LATENCY.
        """
        self.emit('rtcp-report-received', callId, report)

    def on_peerHold(self, callId, peerHold):
        """Emitted when the remote peer places the call on hold."""
        self.emit('peer-hold', callId, int(peerHold))

    def on_audioMuted(self, callId, audioMuted):
        """Emitted when the audio mute state of a call changes."""
        self.emit('audio-muted', callId, int(audioMuted))

    def on_videoMuted(self, callId, videoMuted):
        """Emitted when the video mute state of a call changes."""
        self.emit('video-muted', callId, int(videoMuted))

    def on_onConferenceInfosUpdated(self, confId, infos):
        """Emitted when participant layout info is updated for a conference."""
        self.emit('conference-infos-updated', confId, infos)

    def on_remoteRecordingChanged(self, callId, peerNumber, remoteRecordingState):
        """Emitted when the remote party starts or stops recording."""
        self.emit('remote-recording-changed', callId, peerNumber, int(remoteRecordingState))

    def on_mediaNegotiationStatus(self, callId, event, mediaList):
        account = self.activeCalls.get(callId, {}).get('ACCOUNT_ID', '')
        self.emit('media-negotiation-status', account, callId, event, mediaList)


    #
    # ConfigurationManager
    #

    def on_deviceAuthStateChanged(self, accountId, state, detail):
        """Emitted when the device authentication state changes during account import."""
        self.emit('device-auth-state-changed', accountId, state, detail)

    def on_addDeviceStateChanged(self, accountId, op_id, state, detail):
        """Emitted when the addDevice operation state changes."""
        self.emit('add-device-state-changed', accountId, op_id, state, detail)

    def on_deviceRevocationEnded(self, accountId, deviceId, status):
        """Emitted when revokeDevice completes.

        status: 0=SUCCESS 1=WRONG_PASSWORD 2=UNKNOWN_DEVICE
        """
        self.emit('device-revocation-ended', accountId, deviceId, status)

    def on_accountProfileReceived(self, accountId, displayName, photo):
        """Emitted when a newly created account's profile is available for storage."""
        self.emit('account-profile-received', accountId, displayName, photo)

    def on_knownDevicesChanged(self, accountId, devices):
        """Emitted when a new device linked to this account is found.

        devices is a dict {deviceId: label}.
        """
        self.emit('known-devices-changed', accountId, devices)

    def on_registeredNameFound(self, accountId, requestName, status, address, name):
        """Emitted after lookupName or lookupAddress completes.

        status: 0=SUCCESS 1=INVALID_NAME 2=NOT_FOUND 3=ERROR
        """
        self.emit('registered-name-found', accountId, requestName, status, address, name)

    def on_nameRegistrationEnded(self, accountId, status, name):
        """Emitted after registerName completes.

        status: 0=SUCCESS 1=WRONG_PASSWORD 2=INVALID_NAME 3=ALREADY_TAKEN 4=NETWORK_ERROR
        """
        self.emit('name-registration-ended', accountId, status, name)

    def on_userSearchEnded(self, accountId, status, query, result):
        """Emitted after searchUser completes.

        result is a list of user dicts.
        """
        self.emit('user-search-ended', accountId, status, query, result)

    def on_incomingAccountMessage(self, account, orig, dummy, payloads):
        body = payloads['body']
        if body == "ping": return
        self.emit("account-message-received", account, orig, payloads['body'])

    def on_accountMessageStatusChanged(self, accountId, conversationId, peer, msgId, status):
        """ status:
                SENDING = 0
                SENT = 1
                READ = 2
        """
        if status == 1:
            self.emit('account-message-sent', msgId)
        elif status == 2:
            self.emit('account-message-read', msgId)

    def on_needsHost(self, accountId, conversationId):
        """Emitted when a conversation needs a host for calls."""
        self.emit('needs-host', accountId, conversationId)

    def on_activeCallsChanged(self, accountId, conversationId, activeCalls):
        """Emitted when a conversation has new active calls."""
        self.emit('active-calls-changed', accountId, conversationId, activeCalls)

    def on_profileReceived(self, accountId, from_, path):
        """Emitted when a vCard has been received from a peer."""
        self.emit('profile-received', accountId, from_, path)

    def on_composingStatusChanged(self, accountId, conversationId, contactId, status):
        """Emitted when a peer's message composition status changes.

        status: 0=Idle 1=Active
        """
        self.emit('composing-status-changed', accountId, conversationId, contactId, status)

    def on_volumeChanged(self, device, value):
        """Emitted when the volume level changes (ALSA only).

        device: 'mic' or 'speaker'. value: linear scale [0, 100].
        """
        self.emit('volume-changed', device, value)

    def on_hardwareDecodingChanged(self, state):
        """Emitted when the hardware decoding setting changes."""
        self.emit('hardware-decoding-changed', int(state))

    def on_hardwareEncodingChanged(self, state):
        """Emitted when the hardware encoding setting changes."""
        self.emit('hardware-encoding-changed', int(state))

    def on_audioDeviceEvent(self):
        """Emitted when an audio device is added or removed (e.g., headset unplugged)."""
        self.emit('audio-device-event')

    def on_audioMeter(self, id_, level):
        """Emitted periodically with the RMS volume level of a ring buffer.

        level is in [0, 1]; convert to dB with 20*log10(level).
        """
        self.emit('audio-meter', id_, level)

    def on_accountsChanged(self):
        logger.info("Accounts changed")
        self.emit('accounts-changed')

    def on_accountDetailsChanged(self, accountId, details):
        """Emitted after setAccountDetails is applied with the updated persistent details."""
        self.emit('account-details-changed', accountId, details)

    def on_registrationStateChanged(self, accountId, registrationState, registrationDetail, registrationDetailStr):
        """Emitted when an account's registration state changes.

        registrationDetail is an optional account-type-specific code (0 when unavailable).
        """
        self.emit('registration-state-changed', accountId, registrationState,
                  registrationDetail, registrationDetailStr)

    def on_volatileAccountDetailsChanged(self, accountId, details):
        """Emitted when volatile (runtime) account details change.

        details keys: Account.registrationCoarseStatus, Account.registrationStatus,
        Account.registrationStatusDescription, Account.lastSuccessfulRegister,
        Account.presenceStatus, Account.presenceNote.
        """
        self.emit('volatile-account-details-changed', accountId, details)

    def on_stunStatusFailure(self, reason):
        """Emitted when a STUN status failure occurs."""
        self.emit('stun-status-failure', reason)

    def on_errorAlert(self, code):
        """Emitted when the daemon raises an error alert."""
        self.emit('error-alert', code)

    def on_certificateStateChanged(self, accountId, certId, state):
        """Emitted when a certificate's trust status changes for an account."""
        self.emit('certificate-state-changed', accountId, certId, state)

    def on_certificatePinned(self, certId):
        """Emitted when a certificate is added to the certificate store."""
        self.emit('certificate-pinned', certId)

    def on_certificatePathPinned(self, path, certIds):
        """Emitted when a certificate path is added to the store.

        certIds is the list of certificate IDs found at that path.
        """
        self.emit('certificate-path-pinned', path, certIds)

    def on_certificateExpired(self, certId):
        """Emitted when a pinned certificate expires."""
        self.emit('certificate-expired', certId)

    def on_incomingTrustRequest(self, account, conversation, orig, payload, received):
        """ signal received"""
        account = self._valid_account(account)
        self.onIncomingTrustRequest_cb(account, conversation, orig, payload, received)

    def on_contactAdded(self, account, uri, confirmed):
        """ signal received"""
        account = self._valid_account(account)
        if confirmed:
            self.onContactAdded_cb(account, uri, confirmed)
        else:
            pass

    def on_contactRemoved(self, accountId, uri, banned):
        """Emitted when a contact is removed or banned."""
        self.emit('contact-removed', accountId, uri, int(banned))

    def on_mediaParametersChanged(self, accountId):
        """Emitted when a media parameter changes for an account."""
        self.emit('media-parameters-changed', accountId)

    def on_migrationEnded(self, accountId, result):
        """Emitted when account migration completes.

        result: 'SUCCESS' or 'INVALID'.
        """
        self.emit('migration-ended', accountId, result)

    def on_dataTransferEvent(self, accountId, conversationId, interactionId, fileId, code):
        """Emitted when a data transfer state changes.

        code is a libjami::DataTransferEventCode value.
        """
        self.emit('data-transfer-event', accountId, conversationId, interactionId, fileId, code)

    def on_swarmLoaded(self, id_, account_id, conversation_id, messages):
        """Emitted when a loadConversation request completes.

        id_ matches the request ID returned by loadConversation.
        messages is the list of SwarmMessage structs.
        """
        self.emit('swarm-loaded', id_, account_id, conversation_id, messages)

    def on_messagesFound(self, id_, account_id, conversation_id, messages):
        """Emitted when messages matching a search are found.

        id_ matches the search ID returned by searchConversation.
        """
        self.emit('messages-found', id_, account_id, conversation_id, messages)

    def on_swarmMessageReceived(self, account, conversation, message):
        self.emit('swarm-message-received', account, conversation, message)

    def on_swarmMessageUpdated(self, account_id, conversation_id, message):
        """Emitted when an existing swarm message is edited or updated."""
        self.emit('swarm-message-updated', account_id, conversation_id, message)

    def on_reactionAdded(self, account_id, conversation_id, message_id, reaction):
        """Emitted when a reaction is added to a swarm message."""
        self.emit('reaction-added', account_id, conversation_id, message_id, reaction)

    def on_reactionRemoved(self, account_id, conversation_id, message_id, reaction_id):
        """Emitted when a reaction is removed from a swarm message."""
        self.emit('reaction-removed', account_id, conversation_id, message_id, reaction_id)

    def on_conversationProfileUpdated(self, account_id, conversation_id, profile):
        """Emitted when a conversation profile (title, description, avatar) changes."""
        self.emit('conversation-profile-updated', account_id, conversation_id, profile)

    def on_conversationRequestReceived(self, account_id, conversation_id, metadatas):
        """Emitted when a new conversation invitation is received."""
        self.emit('conversation-request-received', account_id, conversation_id, metadatas)

    def on_conversationRequestDeclined(self, account_id, conversation_id):
        """Emitted when a sent conversation request is declined."""
        self.emit('conversation-request-declined', account_id, conversation_id)

    def on_conversationReady(self, account, conversation):
        self.emit("conversation-ready", account, conversation)

    def on_conversationRemoved(self, account_id, conversation_id):
        """Emitted when a conversation is removed."""
        self.emit('conversation-removed', account_id, conversation_id)

    def on_conversationMemberEvent(self, account_id, conversation_id, member_uri, event):
        """Emitted when a member is invited, added, leaves, or is banned.

        event: 0=add 1=joins 2=leave 3=banned
        """
        self.emit('conversation-member-event', account_id, conversation_id, member_uri, event)

    def on_onConversationError(self, account_id, conversation_id, code, what):
        """Emitted when an error occurs within a conversation."""
        self.emit('conversation-error', account_id, conversation_id, code, what)

    def on_conversationPreferencesUpdated(self, account_id, conversation_id, preferences):
        """Emitted when conversation preferences are updated across devices."""
        self.emit('conversation-preferences-updated', account_id, conversation_id, preferences)

    def on_debugMessageReceived(self, message):
        """Emitted when the daemon outputs a debug log line."""
        self.emit('debug-message-received', message)

    def on_messageSend(self, message):
        """Emitted when a log entry is written in the daemon."""
        self.emit('message-send', message)

    def on_messageReceived(self, account, conversationId, message):
        for key in message:
            pass
        self.emit("conversation-message-received", account, conversationId, message)

    #
    # PresenceManager
    #

    def on_newBuddyNotification(self, accountId, buddyUri, status, lineStatus):
        """Emitted when a registered presence URI's information changes."""
        self.buddyUriList[buddyUri] = status
        self.onSubscriptionStateChanged_cb(accountId, buddyUri, status)
        self.emit('presence-changed', buddyUri, status)

    def on_nearbyPeerNotification(self, accountId, buddyUri, status, displayname):
        """Emitted when a new local peer is discovered."""
        self.buddyUriList[buddyUri] = status
        self.onSubscriptionStateChanged_cb(accountId, buddyUri, status)
        self.emit('presence-changed', buddyUri, status)

    def on_subscriptionStateChanged(self, accountId, buddyUri, status):
        """Emitted when the server changes the state of a subscription."""
        self.buddyUriList[buddyUri] = status
        self.onSubscriptionStateChanged_cb(accountId, buddyUri, status)
        self.emit('presence-changed', buddyUri, int(status))

    def on_newServerSubscriptionRequest(self, buddyUri):
        """Emitted when another user (or the server) requests your presence information."""
        if buddyUri in self.invalidBuddyUris:
            self.subscribeBuddy(buddyUri=buddyUri, flag=False)
        self.onNewServerSubscriptionRequest_cb(buddyUri)
        self.emit('new-server-subscription-request', buddyUri)

    def on_serverError(self, accountId, error, msg):
        """Emitted when a presence server error occurs."""
        self.emit('server-error', accountId, error, msg)

    #
    # Contact management
    #

    #
    # Video management
    #

    def on_deviceEvent(self):
        """Emitted when a v4l2 video device is added or removed (e.g., camera unplugged)."""
        self.emit('device-event')

    def on_decodingStarted(self, id_, shmPath, width, height, isMixer):
        """Emitted when video becomes available in a shared memory buffer.

        id_ is the call ID or 'local' for local preview.
        isMixer is True if this is a conference video mixer.
        """
        self.emit('decoding-started', id_, shmPath, width, height, int(isMixer))

    def on_decodingStopped(self, id_, shmPath, isMixer):
        """Emitted when video is no longer available in a shared memory buffer."""
        self.emit('decoding-stopped', id_, shmPath, int(isMixer))

    def on_fileOpened(self, playerId, info):
        """Emitted when a media player has opened its file and metadata is available.

        info is a dict of media information from the player.
        """
        self.emit('file-opened', playerId, info)

    #
    # plugins manager interface
    #

    def on_webViewMessageReceived(self, pluginId, webViewId, messageId, payload):
        """Emitted when a plugin sends a message up to a client webview."""
        self.emit('web-view-message-received', pluginId, webViewId, messageId, payload)

    ###################################################################
    # Methods
    ###################################################################

    #
    # Instance
    #

    def register(self):
        if self.registered:
            return

        if not self.bus:
            raise CtrlDBusError(("Unable to find %s in DBUS." % DBUS_DEAMON_OBJECT)
                                     + " Check if daemon is running")

        try:
            self.proxy_instance = self._get_proxy("Instance")
            self.proxy_callmgr = self._get_proxy("CallManager")
            self.proxy_confmgr = self._get_proxy("ConfigurationManager")
            self.proxy_videomgr = self._get_proxy("VideoManager")
            self.proxy_presmgr = self._get_proxy("PresenceManager")
            self.proxy_plugins = self._get_proxy("PluginManagerInterface")
        except:
            raise CtrlDBusError("Unable to bind to daemon DBus API")

        try:
            if self.proxy_instance:
                self.instance_handler_id = self.proxy_instance.connect("g-signal", self.on_instance_signal)
            if self.proxy_callmgr:
                self.callmgr_handler_id = self.proxy_callmgr.connect("g-signal", self.on_callmgr_signal)
            if self.proxy_confmgr:
                self.confmgr_handler_id = self.proxy_confmgr.connect("g-signal", self.on_confmgr_signal)
            if self.proxy_videomgr:
                self.videomgr_handler_id = self.proxy_videomgr.connect("g-signal", self.on_videomgr_signal)
            if self.proxy_presmgr:
                self.presmgr_handler_id = self.proxy_presmgr.connect("g-signal", self.on_presmgr_signal)
            if self.proxy_plugins:
                self.plugins_handler_id = self.proxy_plugins.connect("g-signal", self.on_plugins_signal)
        except:
            raise CtrlDBusError("Unable to connect to daemon DBus signals")

        try:
            self.proxy_instance.call_sync("Register", GLib.Variant("(is)", (os.getpid(), self.name, )), Gio.DBusCallFlags.NONE, -1, None)
            self.registered = True
        except:
            raise CtrlDeamonError("Client registration failed")

    def unregister(self):
        if not self.registered:
            return

        try:
            self.proxy_instance.call_sync("Unregister", GLib.Variant("(i)", (os.getpid(),)), Gio.DBusCallFlags.NONE, -1, None)
            self.registered = False
        except:
            raise CtrlDeamonError("Client unregistration failed")
        self.proxy_instance = None
        self.proxy_callmgr = None
        self.proxy_confmgr = None
        self.proxy_videomgr = None
        self.proxy_presmgr = None

    #
    # CallManager
    #

    def placeCall(self, account=None, dest=None):
        """
        Start a call and return a CallID
        """
        try:
            #if len(self.activeCalls) > 0:
            #    self.emit('action-error', _("Cannot dial while in another call"))
            #    return False
            if dest is None or dest == "":
                logger.error("Invalid call destination")
                return
            account = self._valid_account(account)
            if not account: return
            callId = self.proxy_callmgr.call_sync("placeCall",
                                              GLib.Variant("(ss)", (account, dest)),
                                              Gio.DBusCallFlags.NONE, -1, None).unpack()[0]
            if callId:
                # Add the call to the list of active calls
                self.activeCalls[callId] = self.getCallDetails(account=account, callId=callId) or {}
                if not 'CALL_STATE' in self.activeCalls[callId]:
                    self.activeCalls[callId]['CALL_STATE'] = "PENDING"
                self.currentCallId = callId
                self.emit('call-started', callId, self.activeCalls[callId])
            return callId
        except Exception as e:
            logger.error(f"Call error {e}")
            return False

    def placeCallWithMedia(self, account=None, dest=None, mediaList=None):
        """
        Start a call and return a CallID
        """
        try:
            #if len(self.activeCalls) > 0:
            #    self.emit('action-error', _("Cannot dial while in another call"))
            #    return False
            if dest is None or dest == "":
                logger.error("Invalid call destination")
                return
            account = account or self.getAccount()
            if not account: return
            callId = self.proxy_callmgr.call_sync("placeCallWithMedia",
                                              GLib.Variant("(ssas)", (account, dest, mediaList)),
                                              Gio.DBusCallFlags.NONE, -1, None).unpack()[0]
            if callId:
                # Add the call to the list of active calls
                self.activeCalls[callId] = self.getCallDetails(account=account, callId=callId) or {}
                self.currentCallId = callId
                if not 'CALL_STATE' in self.activeCalls[callId]:
                    self.activeCalls[callId]['CALL_STATE'] = "PENDING"
                self.emit('call-started', callId, self.activeCalls[callId])
            return callId
        except Exception as e:
            logger.error(f"CallWithMedia error {e}")
            return False

    def requestMediaChange(self, account, callId, mediaList):
        """Request changes in the media of the specified call (v11.0.0).

        Returns True if the request was accepted.
        mediaList is a list of dicts {str: str} describing the desired media attributes.
        """
        account = self._valid_account(account)
        if not account: return False
        return self.proxy_callmgr.call_sync("requestMediaChange",
                                    GLib.Variant("(ssaa{ss})", (account, callId, mediaList)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def refuse(self, account=None, callId=None):
        """
        Refuse an incoming call identified by a CallID
        """
        account = self._valid_account(account)
        if not account: return
        if callId is None or callId == "":
            logger.error("Invalid callID")
            return
        return self.proxy_callmgr.call_sync("refuse",
                                    GLib.Variant("(ss)", (account, callId,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()

    def accept(self, account=None, callId=None):
        """
        Accept an incoming call identified by a CallID
        """
        account = self._valid_account(account)
        if not account: return
        if callId is None or callId == "":
            logger.error("Invalid callID")
            return
        return self.proxy_callmgr.call_sync("accept",
                                    GLib.Variant("(ss)", (account, callId,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()

    def acceptWithMedia(self, account=None, callId=None, mediaList=None):
        """Accept call with explicit media list (v11.0.0).

        Allows controlling attributes for each medium (accepted, muted, …).
        mediaList is a list of dicts {str: str}.
        Returns True on success.
        """
        account = self._valid_account(account)
        if not account or not callId: return False
        return self.proxy_callmgr.call_sync("acceptWithMedia",
                                    GLib.Variant("(ssaa{ss})", (account, callId, mediaList or [])),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def answerMediaChangeRequest(self, account=None, callId=None, mediaList=None):
        """Answer a media update request (v11.0.0).

        mediaList must have the same size as the media list in the original request.
        An empty list refuses the change.  Returns True on success.
        """
        account = self._valid_account(account)
        if not account or not callId: return False
        return self.proxy_callmgr.call_sync("answerMediaChangeRequest",
                                    GLib.Variant("(ssaa{ss})", (account, callId, mediaList or [])),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def hangUp(self, account=None, callId=None):
        """
        End a call identified by a CallID
        """
        account = self._valid_account(account)
        if not account: return
        if callId is None or callId == "":
            pass # just to see
        return self.proxy_callmgr.call_sync("hangUp",
                                    GLib.Variant("(ss)", (account, callId,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()

    def hangUpConference(self, account=None, confId=None):
        """
        End a call identified by a CallID
        """
        account = self._valid_account(account)
        if not account: return
        if confId is None or confId == "":
            pass # just to see
        return self.proxy_callmgr.call_sync("hangUpConference",
                                    GLib.Variant("(ss)", (account, confId,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()

    def hold(self, account=None, callId=None):
        """
        Hold a call identified by a CallID
        """
        account = self._valid_account(account)
        if not account: return
        if callId is None or callId == "":
            logger.error("Invalid callID")
            return
        return self.proxy_callmgr.call_sync("hold",
                                    GLib.Variant("(ss)", (account, callId,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()

    def unhold(self, account=None, callId=None):
        """
        Unhold an incoming call identified by a CallID
        """
        account = self._valid_account(account)
        if not account: return
        if callId is None or callId == "":
            logger.error("Invalid callID")
            return
        return self.proxy_callmgr.call_sync("unhold",
                                    GLib.Variant("(ss)", (account, callId,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()

    def muteLocalMedia(self, account=None, mute=False):
        account = self._valid_account(account)
        if not account: return
        try:
            callId = self.currentCallId
            if callId is None or callId == "":
                return False
            mediaType = "AUDIO"
            return self.proxy_callmgr.call_sync("muteLocalMedia",
                                    GLib.Variant("(sssb)", (account, callId, mediaType, mute)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()
        except Exception as e:
            logger.error(f"muteLocalMedia failed with {e}")

    def muteCall(self, account=None, callId=None, muted=False):
        """Mute or unmute the audio track of a specific call."""
        account = self._valid_account(account)
        if not account or not callId:
            return
        try:
            return self.proxy_callmgr.call_sync("muteLocalMedia",
                                    GLib.Variant("(sssb)", (account, callId, "AUDIO", muted)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()
        except Exception as e:
            logger.error(f"muteCall failed with {e}")

    def transfer(self, account=None, callId=None, to=None):
        """
        Transfert a call identified by a CallID
        'to' is a jid
        """
        account = self._valid_account(account)
        if not account: return
        if not account or not callId or not to:
            logger.error("params should not be None!")
            return None
        return self.proxy_callmgr.call_sync("transfer",
                                    GLib.Variant("(sss)", (account, callId, to,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()

    def attendedTransfer(self, account=None, callId=None, to=None):
        """
        Transfert a call identified by a CallID
        'to' is a callId
        """
        account = self._valid_account(account)
        if not account: return
        if not account or not callId or not to:
            logger.error("params should not be None!")
            return None
        return self.proxy_callmgr.call_sync("attendedTransfer",
                                    GLib.Variant("(sss)", (account, callId, to,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()

    def playDTMF(self, key):
        """Send a DTMF"""
        self.proxy_callmgr.call_sync("playDTMF",
                                    GLib.Variant("(s)", (key,)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def startTone(self, start, tone_type):
        """Start audio stream and play a tone.

        start: 1 to start, 0 to stop.
        tone_type: integer tone identifier.
        """
        self.proxy_callmgr.call_sync("startTone",
                                    GLib.Variant("(ii)", (start, tone_type)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def joinParticipant(self, account, sel_callId, account2, drag_callId):
        """Join two calls into a 3-way conference (v11.0.0).

        Emits conferenceCreated on success.  Returns True on success.
        """
        return self.proxy_callmgr.call_sync("joinParticipant",
                                    GLib.Variant("(ssss)", (account, sel_callId, account2, drag_callId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def createConfFromParticipantList(self, account, participants):
        """Create a conference from a list of participant URIs (v11.0.0).

        participants is a list of strings.  Emits conferenceCreated on success.
        """
        self.proxy_callmgr.call_sync("createConfFromParticipantList",
                                    GLib.Variant("(sas)", (account, participants)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def setConferenceLayout(self, account, confId, layout):
        """Change displayed layout for a conference (v11.0.0).

        layout: 0 = grid, 1 = one big + small previews, 2 = single participant.
        """
        self.proxy_callmgr.call_sync("setConferenceLayout",
                                    GLib.Variant("(ssu)", (account, confId, layout)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def setActiveParticipant(self, account, confId, callId):
        """Set which call is shown prominently in a conference (v11.0.0)."""
        self.proxy_callmgr.call_sync("setActiveParticipant",
                                    GLib.Variant("(sss)", (account, confId, callId)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def setActiveStream(self, account, confId, accountUri, deviceId, streamId, state):
        """Set the active stream in a conference (v13.1.0)."""
        self.proxy_callmgr.call_sync("setActiveStream",
                                    GLib.Variant("(ssssssb)", (account, confId, accountUri, deviceId, streamId, state)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def setModerator(self, account, confId, peerId, state):
        """Grant or revoke moderator role for a conference participant (v11.0.0)."""
        self.proxy_callmgr.call_sync("setModerator",
                                    GLib.Variant("(sssb)", (account, confId, peerId, state)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def muteParticipant(self, account, confId, peerId, state):
        """Mute (True) or unmute (False) a conference participant (v11.0.0)."""
        self.proxy_callmgr.call_sync("muteParticipant",
                                    GLib.Variant("(sssb)", (account, confId, peerId, state)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def muteStream(self, account, confId, accountUri, deviceId, streamId, state):
        """Mute a specific stream of a conference participant (v13.1.0)."""
        self.proxy_callmgr.call_sync("muteStream",
                                    GLib.Variant("(sssssb)", (account, confId, accountUri, deviceId, streamId, state)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def isConferenceParticipant(self, account, callId):
        """Return True if the call is part of a conference (v11.0.0)."""
        return self.proxy_callmgr.call_sync("isConferenceParticipant",
                                    GLib.Variant("(ss)", (account, callId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def raiseParticipantHand(self, account, confId, peerId, state):
        """Raise or lower a participant's hand in a conference (v11.0.0)."""
        self.proxy_callmgr.call_sync("raiseParticipantHand",
                                    GLib.Variant("(sssb)", (account, confId, peerId, state)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def raiseHand(self, account, confId, accountUri, deviceId, state):
        """Raise or lower hand for a specific stream (v13.1.0)."""
        self.proxy_callmgr.call_sync("raiseHand",
                                    GLib.Variant("(ssssb)", (account, confId, accountUri, deviceId, state)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def hangupParticipant(self, account, confId, peerId, deviceId):
        """Hang up a specific participant in a conference (v11.0.0)."""
        self.proxy_callmgr.call_sync("hangupParticipant",
                                    GLib.Variant("(ssss)", (account, confId, peerId, deviceId)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def addParticipant(self, account, callId, account2, confId):
        """Add a call to an existing conference (v11.0.0).

        Emits conferenceChanged on success.  Returns True on success.
        """
        return self.proxy_callmgr.call_sync("addParticipant",
                                    GLib.Variant("(ssss)", (account, callId, account2, confId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def addMainParticipant(self, account, confId):
        """Re-join the local user into a conference (v11.0.0).

        Puts the current call on HOLD or detaches from another conference.
        Returns True on success.
        """
        return self.proxy_callmgr.call_sync("addMainParticipant",
                                    GLib.Variant("(ss)", (account, confId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def detachLocalParticipant(self):
        """Detach local participant from the conference (v3.0.0).

        Remote participants are placed on hold.  Emits conferenceChanged.
        Returns True on success.
        """
        return self.proxy_callmgr.call_sync("detachLocalParticipant",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def detachParticipant(self, account, callId):
        """Detach a call from its conference (v11.0.0).

        If only one participant remains, emits conferenceRemoved.
        Returns True on success.
        """
        return self.proxy_callmgr.call_sync("detachParticipant",
                                    GLib.Variant("(ss)", (account, callId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def joinConference(self, account, sel_confId, account2, drag_confId):
        """Join two conferences together (v11.0.0).  Returns True on success."""
        return self.proxy_callmgr.call_sync("joinConference",
                                    GLib.Variant("(ssss)", (account, sel_confId, account2, drag_confId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getConferenceDetails(self, account=None, confId=None):
        """
        Return information on this conference if exists
        """
        account = self._valid_account(account)
        if not account or not confId:
            logger.error("params should not be None!")
            return None
        return self.proxy_callmgr.call_sync("getConferenceDetails",
                                            GLib.Variant("(ss)", (account, confId,)),
                                            Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getConferenceList(self, account=None):
        """
        Return all conferences handled by the daemon
        """
        account = self._valid_account(account)
        if not account:
            logger.error("params should not be None!")
            return None
        return [str(x) for x in
                self.proxy_callmgr.call_sync("getConferenceList",
                                             GLib.Variant("(s)", (account,)),
                                             Gio.DBusCallFlags.NONE, -1, None).unpack()]

    def getConferenceId(self, account, callId):
        """Return the conference ID the call belongs to, or '' (v11.0.0)."""
        return self.proxy_callmgr.call_sync("getConferenceId",
                                    GLib.Variant("(ss)", (account, callId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def toggleRecording(self, account, callId):
        """Toggle recording for a call (v11.0.0).  Returns True if now recording."""
        return self.proxy_callmgr.call_sync("toggleRecording",
                                    GLib.Variant("(ss)", (account, callId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getIsRecording(self, account, callId):
        """Return True if the call is currently being recorded (v11.0.0)."""
        return self.proxy_callmgr.call_sync("getIsRecording",
                                    GLib.Variant("(ss)", (account, callId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def recordPlaybackSeek(self, value):
        """Set playback position using a linear scale [0, 100]."""
        self.proxy_callmgr.call_sync("recordPlaybackSeek",
                                    GLib.Variant("(d)", (value,)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def getCallDetails(self, account=None, callId=None):
        """
        Return information on this call if exists
        """
        account = self._valid_account(account)
        if not account or not callId:
            logger.error("params should not be None!")
            return None
        ret = self.proxy_callmgr.call_sync("getCallDetails",
                                             GLib.Variant("(ss)", (account, callId,)),
                                             Gio.DBusCallFlags.NONE, -1, None).unpack()[0]
        return ret

    def getCallList(self, account=None):
        """
        Return all calls handled by the daemon
        """
        account = self._valid_account(account)
        if not account:
            logger.error("params should not be None!")
            return None
        return [str(x) for x in
                self.proxy_callmgr.call_sync("getCallList",
                                             GLib.Variant("(s)", (account,)),
                                             Gio.DBusCallFlags.NONE, -1, None).unpack()]

    def switchInput(self, account, callId, inputUri):
        """Switch the video input source for a call (v11.0.0).  Returns True on success."""
        return self.proxy_callmgr.call_sync("switchInput",
                                    GLib.Variant("(sss)", (account, callId, inputUri)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def switchSecondaryInput(*args):
        """Not described in installed D-Bus XML."""
        pass

    def sendTextMessageInCall(self, account, callId, message):
        return self.proxy_callmgr.call_sync("sendTextMessage",
                                             GLib.Variant("(ssa{ss}b)", (account, callId, message,)),
                                             Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getConferenceInfos(self, account, confId):
        """Retrieve the participant layout info for a conference (v11.0.0).

        Returns a list of dicts with keys uri, x, y, w, h.
        """
        return self.proxy_callmgr.call_sync("getConferenceInfos",
                                    GLib.Variant("(ss)", (account, confId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getParticipantList(self, account, confId):
        """Return the list of call IDs participating in a conference (v11.0.0)."""
        return self.proxy_callmgr.call_sync("getParticipantList",
                                    GLib.Variant("(ss)", (account, confId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def holdConference(self, account, confId):
        """Place every call in a conference on HOLD (v11.0.0).  Returns True on success."""
        return self.proxy_callmgr.call_sync("holdConference",
                                    GLib.Variant("(ss)", (account, confId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def unholdConference(self, account, confId):
        """Resume every call in a conference from HOLD (v11.0.0).  Returns True on success.

        The D-Bus method name is resumeConference in the XML v11.0.0.
        """
        return self.proxy_callmgr.call_sync("resumeConference",
                                    GLib.Variant("(ss)", (account, confId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def startRecordedFilePlayback(self, filepath):
        """Start playback of a previously recorded file.  Returns True on success."""
        return self.proxy_callmgr.call_sync("startRecordedFilePlayback",
                                    GLib.Variant("(s)", (filepath,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def stopRecordedFilePlayback(self):
        """Stop playback of a recorded file."""
        self.proxy_callmgr.call_sync("stopRecordedFilePlayback",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None)

    def currentMediaList(self, account, callId):
        """Return the list of active media in a call or conference (v13.3.0).

        Each item is a dict {str: str} with media attributes.
        """
        return self.proxy_callmgr.call_sync("currentMediaList",
                                    GLib.Variant("(ss)", (account, callId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    #
    # ConfigurationManager
    #

    def getAccountTemplate(self, accountType):
        """Return a template dict of settings for the given account type (SIP, RING, …)."""
        return self.proxy_confmgr.call_sync("getAccountTemplate",
                                    GLib.Variant("(s)", (accountType,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getAccountDetails(self, account=None):
        """Return a list of string. If no account is provided, active account is used"""
        account = self._valid_account(account)
        if not account: return
        if self.isAccountExists(account):
            ret = self.proxy_confmgr.call_sync("getAccountDetails",
                                                GLib.Variant("(s)", (account,)),
                                                Gio.DBusCallFlags.NONE, -1, None).unpack()[0]
            return ret
        return []

    def getVolatileAccountDetails(self, account=None):
        """Return a list of string. If no account is provided, active account is used"""
        account = self._valid_account(account)
        if not account: return
        if self.isAccountExists(account):
            ret = self.proxy_confmgr.call_sync("getVolatileAccountDetails",
                                                GLib.Variant("(s)", (account,)),
                                                Gio.DBusCallFlags.NONE, -1, None).unpack()[0]
            return ret
        return []

    def setAccountActive(self, account, enable):
        """Set the runtime active state of an account (no impact on 'enabled' flag)."""
        account = self._valid_account(account)
        if not account: return
        self.proxy_confmgr.call_sync("setAccountActive",
                                    GLib.Variant("(sb)", (account, enable)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def setCredentials(self, account, credentialInformation):
        """Set the SIP credential list for an account.

        credentialInformation is a list of dicts {str: str}.
        """
        account = self._valid_account(account)
        if not account: return
        self.proxy_confmgr.call_sync("setCredentials",
                                    GLib.Variant("(saa{ss})", (account, credentialInformation)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def getCredentials(self, account):
        """Return the SIP credential list for an account as a list of dicts."""
        account = self._valid_account(account)
        if not account: return []
        return self.proxy_confmgr.call_sync("getCredentials",
                                    GLib.Variant("(s)", (account,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def addAccount(self, details=None):
        """Add a new account account

        Add a new account to the daemon. Default parameters are \
        used for missing account configuration field.

        Required parameters are type, alias, hostname, username and password

        input details = {
        "Account.type": DEFAUL_ACCT_TYPE,
        "Account.alias": alias,
        "Account.hostname": hostname,
        "Account.username": username,
        "Account.password": password,
        }
        """
        if details is None:
            raise CtrlAccountError("Must specifies type, alias, hostname, \
                                  username and password in \
                                  order to create a new account")
        return str(self.proxy_confmgr.call_sync("addAccount",
                                                GLib.Variant("(a{ss})", (details,)),
                                                Gio.DBusCallFlags.NONE, -1, None).unpack()[0])

    def exportToFile(self, account, destinationPath, scheme="", password=""):
        """Copy the account archive to destinationPath (v15.0.0).

        scheme: '' (no encryption), 'password', or 'key' (base64 binary key).
        Returns True if initialised successfully.
        """
        account = self._valid_account(account)
        if not account: return False
        return self.proxy_confmgr.call_sync("exportToFile",
                                    GLib.Variant("(ssss)", (account, destinationPath, scheme, password)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def provideAccountAuthentication(self, account, credentialsFromUser, scheme=""):
        """Provide authentication credentials to the daemon (v15.0.0).

        scheme: '' (no encryption), 'password', or 'key'.
        Returns True on success.
        """
        account = self._valid_account(account)
        if not account: return False
        return self.proxy_confmgr.call_sync("provideAccountAuthentication",
                                    GLib.Variant("(sss)", (account, credentialsFromUser, scheme)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def addDevice(self, account, uri):
        """Initiate adding a new device to the account (v16.0.0).

        Returns an operation ID (int); monitor addDeviceStateChanged for progress.
        """
        account = self._valid_account(account)
        if not account: return -1
        return self.proxy_confmgr.call_sync("addDevice",
                                    GLib.Variant("(ss)", (account, uri)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def confirmAddDevice(self, account, op_id):
        """Confirm the addition of a new device (v16.0.0).  Returns True on success."""
        account = self._valid_account(account)
        if not account: return False
        return self.proxy_confmgr.call_sync("confirmAddDevice",
                                    GLib.Variant("(su)", (account, op_id)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def cancelAddDevice(self, account, op_id):
        """Cancel the addition of a new device (v16.0.0).  Returns True on success."""
        account = self._valid_account(account)
        if not account: return False
        return self.proxy_confmgr.call_sync("cancelAddDevice",
                                    GLib.Variant("(su)", (account, op_id)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def revokeDevice(self, account, deviceId, scheme="", password=""):
        """Revoke a device and publish the new revocation list (v15.0.0).

        scheme: '' (no encryption), 'password', or 'key'.
        Returns True on success; monitor deviceRevocationEnded for the async result.
        """
        account = self._valid_account(account)
        if not account: return False
        return self.proxy_confmgr.call_sync("revokeDevice",
                                    GLib.Variant("(ssss)", (account, deviceId, scheme, password)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getKnownRingDevices(self, account=None):
        account = self._valid_account(account)
        if not account: return
        return self.proxy_confmgr.call_sync("getKnownRingDevices",
                                                GLib.Variant("(s)", (account,)),
                                                Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def changeAccountPassword(self, account, oldPassword, newPassword):
        """Change the account archive password.  Returns True on success."""
        account = self._valid_account(account)
        if not account: return False
        return self.proxy_confmgr.call_sync("changeAccountPassword",
                                    GLib.Variant("(sss)", (account, oldPassword, newPassword)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def lookupName(self, account, nameserverUri, name):
        """Perform a name lookup (v2.2.0).

        Returns True if started; result arrives via registeredNameFound signal.
        Pass account='' to use the default nameserver.
        """
        return self.proxy_confmgr.call_sync("lookupName",
                                    GLib.Variant("(sss)", (account or "", nameserverUri or "", name)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def lookupAddress(self, account, nameserverUri, address):
        """Perform an address lookup (v2.2.0).

        Returns True if started; result arrives via registeredNameFound signal.
        """
        return self.proxy_confmgr.call_sync("lookupAddress",
                                    GLib.Variant("(sss)", (account or "", nameserverUri or "", address)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def registerName(self, account, name, scheme="", password=""):
        """Register a name with the Jami nameserver (v2.2.0).

        name must be lower-case ASCII, digits, '-' or '_'.
        Returns True if started; result arrives via nameRegistrationEnded signal.
        """
        account = self._valid_account(account)
        if not account: return False
        return self.proxy_confmgr.call_sync("registerName",
                                    GLib.Variant("(ssss)", (account, name, scheme, password)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def searchUser(self, account, query):
        """Search users in the remote directory for this account.

        Returns True if started; results arrive via userSearchEnded signal.
        """
        account = self._valid_account(account)
        if not account: return False
        return self.proxy_confmgr.call_sync("searchUser",
                                    GLib.Variant("(ss)", (account, query)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setAccountsOrder(self, order):
        """Update the display/priority order of accounts.

        order is a string of account IDs delimited by '/'.
        """
        self.proxy_confmgr.call_sync("setAccountsOrder",
                                    GLib.Variant("(s)", (order,)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def removeAccount(self, account=None):
        """Remove an account from internal list"""
        if account is None:
            return False
        if not account: return
        return self.proxy_confmgr.call_sync("removeAccount",
                                     GLib.Variant("(s)", (account,)),
                                     Gio.DBusCallFlags.NONE, -1, None).unpack()

    def getAccountList(self):
        return self.getAllAccounts(account_type=None)

    def getAllAccounts(self, account_type=None):
        """Return a list with all accounts"""
        if self.proxy_confmgr:
            l = self.proxy_confmgr.call_sync("getAccountList", None, Gio.DBusCallFlags.NONE, -1, None).unpack()[0]
        else:
            return []
        acclist =  map(str, l)
        reslist = []
        for a in acclist:
            acc = a.strip("'[]")
            if acc != '':
                reslist.append(acc)
        if account_type:
            reslist = filter(partial(self.isAccountOfType, account_type), reslist)
        return list(reslist)

    def registerAllAccounts(self):
        """Send REGISTER for all accounts, even disabled ones."""
        self.proxy_confmgr.call_sync("registerAllAccounts",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None)

    def sendRegister(self, account, enable):
        """Register (enable=True) or unregister (enable=False) an account."""
        account = self._valid_account(account)
        if not account: return
        self.proxy_confmgr.call_sync("sendRegister",
                                    GLib.Variant("(sb)", (account, enable)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def sendTextMessage(self, account, dest, message, flag):
        #payload = {'body' : bytearray(payload.encode('utf_8'))}
        payload = {'body' : message}
        msgId = self.proxy_confmgr.call_sync("sendTextMessage",
                                             GLib.Variant("(ssa{ss}i)", (account, dest, payload, flag,)),
                                             Gio.DBusCallFlags.NONE, -1, None).unpack()[0]
        return msgId

    def cancelMessage(*args):
        """Not described in installed D-Bus XML."""
        pass

    def getLastMessages(self, account, base_timestamp):
        """Return messages received since base_timestamp (Unix t).

        Returns a list of tuples (from, payload_dict, timestamp).
        """
        account = self._valid_account(account)
        if not account: return []
        return self.proxy_confmgr.call_sync("getLastMessages",
                                    GLib.Variant("(st)", (account, base_timestamp)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getNearbyPeers(self, account):
        """Return a map of discovered nearby peers {uri: info}."""
        account = self._valid_account(account)
        if not account: return {}
        return self.proxy_confmgr.call_sync("getNearbyPeers",
                                    GLib.Variant("(s)", (account,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def updateProfile(self, account, displayName, avatar, fileType, flag):
        """Update account profile and push it to peers.

        flag: 0 = avatar from path, 1 = avatar from base64, 2 = remove avatar.
        """
        account = self._valid_account(account)
        if not account: return
        self.proxy_confmgr.call_sync("updateProfile",
                                    GLib.Variant("(ssssi)", (account, displayName, avatar, fileType, flag)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def getMessageStatus(self, msg_id):
        """Return the delivery status of a message by its ID (DEPRECATED in daemon).

        Status codes: 0=UNKNOWN, 1=SENDING, 2=SENT, 3=READ, 4=FAILURE.
        """
        return self.proxy_confmgr.call_sync("getMessageStatus",
                                    GLib.Variant("(t)", (msg_id,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setIsComposing(self, account, conversationUri, isComposing):
        """Send a composing-status notification to a contact/conversation (v7.9.0).

        conversationUri: 'swarm:xxxx' or 'jami:xxxx'.
        """
        account = self._valid_account(account)
        if not account: return
        self.proxy_confmgr.call_sync("setIsComposing",
                                    GLib.Variant("(ssb)", (account, conversationUri, isComposing)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def setMessageDisplayed(self, account, conversationUri, messageId, status):
        """Inform the daemon that a message was displayed (v8.1.0).

        status: 3 = displayed.  Returns True on success.
        """
        account = self._valid_account(account)
        if not account: return False
        return self.proxy_confmgr.call_sync("setMessageDisplayed",
                                    GLib.Variant("(sssi)", (account, conversationUri, messageId, status)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setVolume(self, device, value):
        """Set the volume of 'mic' or 'speaker' on a linear scale [0, 100] (ALSA only)."""
        self.proxy_confmgr.call_sync("setVolume",
                                    GLib.Variant("(sd)", (device, value)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def getVolume(self, device):
        """Return the volume of 'mic' or 'speaker' on a linear scale [0, 100] (ALSA only)."""
        return self.proxy_confmgr.call_sync("getVolume",
                                    GLib.Variant("(s)", (device,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def muteDtmf(self, mute):
        """Mute (True) or unmute (False) DTMF tones."""
        self.proxy_confmgr.call_sync("muteDtmf",
                                    GLib.Variant("(b)", (mute,)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def isDtmfMuted(self):
        """Return True if DTMF tones are currently muted."""
        return self.proxy_confmgr.call_sync("isDtmfMuted",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def muteCapture(self, flag):
        self.proxy_confmgr.call_sync("muteCapture",
                                     GLib.Variant("(b)", (flag,)),
                                     Gio.DBusCallFlags.NONE, -1, None)

    def isCaptureMuted(self):
        return self.proxy_confmgr.call_sync("isCaptureMuted",
                                     None,
                                     Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def mutePlayback(self, flag):
        self.proxy_confmgr.call_sync("mutePlayback",
                                     GLib.Variant("(b)", (flag,)),
                                     Gio.DBusCallFlags.NONE, -1, None)

    def isPlaybackMuted(self):
        return self.proxy_confmgr.call_sync("isPlaybackMuted",
                                     None,
                                     Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def muteRingtone(self, flag):
        self.proxy_confmgr.call_sync("muteRingtone",
                                     GLib.Variant("(b)", (flag,)),
                                     Gio.DBusCallFlags.NONE, -1, None)

    def isRingtoneMuted(self):
        return self.proxy_confmgr.call_sync("isRingtoneMuted",
                                     None,
                                     Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getAudioManager(self):
        api = self.proxy_confmgr.call_sync("getAudioManager",
                                     None,
                                     Gio.DBusCallFlags.NONE, -1, None).unpack()[0]
        return api

    def setAudioManager(self, api):
        flag = self.proxy_confmgr.call_sync("setAudioManager",
                                     GLib.Variant("(s)", (api,)),
                                     Gio.DBusCallFlags.NONE, -1, None).unpack()[0]
        return flag

    def getSupportedAudioManagers(self):
        apis = self.proxy_confmgr.call_sync("getSupportedAudioManagers",
                                     None,
                                     Gio.DBusCallFlags.NONE, -1, None).unpack()[0]
        return apis

    def getRecordPath(self):
        """Return the directory path used for recordings."""
        return self.proxy_confmgr.call_sync("getRecordPath",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setRecordPath(self, path):
        """Set the directory path used for recordings."""
        self.proxy_confmgr.call_sync("setRecordPath",
                                    GLib.Variant("(s)", (path,)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def getIsAlwaysRecording(self):
        """Return True if the daemon records all calls automatically."""
        return self.proxy_confmgr.call_sync("getIsAlwaysRecording",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setIsAlwaysRecording(self, enabled):
        """Enable or disable automatic recording of all calls."""
        self.proxy_confmgr.call_sync("setIsAlwaysRecording",
                                    GLib.Variant("(b)", (enabled,)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def getRecordPreview(self):
        """Return True if local video preview is recorded."""
        return self.proxy_confmgr.call_sync("getRecordPreview",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setRecordPreview(self, enabled):
        """Enable or disable recording of the local video preview."""
        self.proxy_confmgr.call_sync("setRecordPreview",
                                    GLib.Variant("(b)", (enabled,)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def getRecordQuality(self):
        """Return the recording quality level (integer)."""
        return self.proxy_confmgr.call_sync("getRecordQuality",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setRecordQuality(self, quality):
        """Set the recording quality level (integer)."""
        self.proxy_confmgr.call_sync("setRecordQuality",
                                    GLib.Variant("(i)", (quality,)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def getCodecList(self):
        """Return the list of all codec IDs supported by the daemon."""
        return self.proxy_confmgr.call_sync("getCodecList",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getCodecDetails(self, account, codecId):
        """Return a dict of details for a given codec ID on an account."""
        account = self._valid_account(account)
        if not account: return {}
        return self.proxy_confmgr.call_sync("getCodecDetails",
                                    GLib.Variant("(su)", (account, codecId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setCodecDetails(self, account, codecId, details):
        """Update the details dict for a given codec ID on an account.  Returns True on success."""
        account = self._valid_account(account)
        if not account: return False
        return self.proxy_confmgr.call_sync("setCodecDetails",
                                    GLib.Variant("(sua{ss})", (account, codecId, details)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getActiveCodecList(self, account=None):
        """Return the list of active codec IDs for an account."""
        account = self._valid_account(account)
        if not account: return []
        return self.proxy_confmgr.call_sync("getActiveCodecList",
                                    GLib.Variant("(s)", (account,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setActiveCodecList(self, account=None, codec_list=''):
        """Activate given codecs on an account. If no account is provided, active account is used"""
        account = self._valid_account(account)
        if not account: return
        if self.isAccountExists(account):
            codec_list = [int(x) for x in codec_list.split(',')]
            self.configurationmanager.setActiveCodecList(account, codec_list)
            return self.proxy_confmgr.call_sync("setActiveCodecList",
                                        GLib.Variant("(sau)", (account, codec_list,)),
                                        Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getAudioPluginList(self):
        return self.proxy_confmgr.call_sync("getAudioPluginList",
                                     None,
                                     Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setAudioPlugin(self, audioPlugin):
        """Set the active audio plugin."""
        self.proxy_confmgr.call_sync("setAudioPlugin",
                                    GLib.Variant("(s)", (audioPlugin,)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def getAudioOutputDeviceList(self):
        return self.proxy_confmgr.call_sync("getAudioOutputDeviceList",
                                     None,
                                     Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setAudioOutputDevice(self, index):
        self.proxy_confmgr.call_sync("setAudioOutputDevice",
                                     GLib.Variant("(i)", (index,)),
                                     Gio.DBusCallFlags.NONE, -1, None)

    def setAudioInputDevice(self, index):
        self.proxy_confmgr.call_sync("setAudioInputDevice",
                                     GLib.Variant("(i)", (index,)),
                                     Gio.DBusCallFlags.NONE, -1, None)

    def setAudioRingtoneDevice(self, index):
        self.proxy_confmgr.call_sync("setAudioRingtoneDevice",
                                     GLib.Variant("(i)", (index,)),
                                     Gio.DBusCallFlags.NONE, -1, None)

    def getAudioInputDeviceList(self):
        return self.proxy_confmgr.call_sync("getAudioInputDeviceList",
                                     None,
                                     Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getCurrentAudioDevicesIndex(self):
        return self.proxy_confmgr.call_sync("getCurrentAudioDevicesIndex",
                                     None,
                                     Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getAudioInputDeviceIndex(self, device):
        return self.proxy_confmgr.call_sync("getAudioInputDeviceIndex",
                                     GLib.Variant("(s)", (device,)),
                                     Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getAudioOutputDeviceIndex(self, device):
        return self.proxy_confmgr.call_sync("getAudioOutputDeviceIndex",
                                     GLib.Variant("(s)", (device,)),
                                     Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getCurrentAudioOutputPlugin(self):
        return self.proxy_confmgr.call_sync("getCurrentAudioOutputPlugin",
                                     None,
                                     Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def isAudioMeterActive(self, ring_buffer_id):
        return self.proxy_confmgr.call_sync("isAudioMeterActive",
                                     GLib.Variant("(s)", (ring_buffer_id,)),
                                     Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setAudioMeterState(self, ring_buffer_id, flag):
        self.proxy_confmgr.call_sync("setAudioMeterState",
                                     GLib.Variant("(sb)", (ring_buffer_id, flag,)),
                                     Gio.DBusCallFlags.NONE, -1, None)

    def getNoiseSuppressState(self):
        return self.proxy_confmgr.call_sync("getNoiseSuppressState",
                                     None,
                                     Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setNoiseSuppressState(self, state):
        self.proxy_confmgr.call_sync("setNoiseSuppressState",
                                     GLib.Variant("(s)", (state,)),
                                     Gio.DBusCallFlags.NONE, -1, None)

    def getEchoCancellationState(self):
        return self.proxy_confmgr.call_sync("getEchoCancellationState",
                                     None,
                                     Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setEchoCancellationState(self, state):
        self.proxy_confmgr.call_sync("setEchoCancellationState",
                                     GLib.Variant("(s)", (state,)),
                                     Gio.DBusCallFlags.NONE, -1, None)

    def getVoiceActivityDetectionState(self):
        return self.proxy_confmgr.call_sync("getVoiceActivityDetectionState",
                                     None,
                                     Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setVoiceActivityDetectionState(self, state):
        self.proxy_confmgr.call_sync("setVoiceActivityDetectionState",
                                     GLib.Variant("(b)", (state,)),
                                     Gio.DBusCallFlags.NONE, -1, None)

    def isAgcEnabled(self):
        return self.proxy_confmgr.call_sync("isAgcEnabled",
                                     None,
                                     Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setAgcState(self, state):
        self.proxy_confmgr.call_sync("setAgcState",
                                     GLib.Variant("(b)", (state,)),
                                     Gio.DBusCallFlags.NONE, -1, None)

    def getHistoryLimit(self):
        """Return the history retention limit in days."""
        return self.proxy_confmgr.call_sync("getHistoryLimit",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setHistoryLimit(self, days):
        """Set the history retention limit in days."""
        self.proxy_confmgr.call_sync("setHistoryLimit",
                                    GLib.Variant("(i)", (days,)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def getRingingTimeout(self):
        """Return the outgoing call ringing timeout in seconds."""
        return self.proxy_confmgr.call_sync("getRingingTimeout",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setRingingTimeout(self, timeout):
        """Set the outgoing call ringing timeout in seconds."""
        self.proxy_confmgr.call_sync("setRingingTimeout",
                                    GLib.Variant("(i)", (timeout,)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def getSupportedTlsMethod(self):
        """Return the list of supported TLS method strings."""
        return self.proxy_confmgr.call_sync("getSupportedTlsMethod",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getSupportedCiphers(self, account):
        """Return the list of supported TLS cipher names for a SIP account (v2.0.0)."""
        account = self._valid_account(account)
        if not account: return []
        return self.proxy_confmgr.call_sync("getSupportedCiphers",
                                    GLib.Variant("(s)", (account,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def validateCertificate(self, account, certificate):
        """Return a dict of validation results for a certificate ID."""
        account = self._valid_account(account)
        if not account: return {}
        return self.proxy_confmgr.call_sync("validateCertificate",
                                    GLib.Variant("(ss)", (account, certificate)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getCertificateDetails(self, account, certificate):
        """Return a dict of details for a certificate ID."""
        account = self._valid_account(account)
        if not account: return {}
        return self.proxy_confmgr.call_sync("getCertificateDetails",
                                    GLib.Variant("(ss)", (account, certificate)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getPinnedCertificates(self, account):
        """Return the list of pinned certificate IDs for an account (v2.2.0)."""
        account = self._valid_account(account)
        if not account: return []
        return self.proxy_confmgr.call_sync("getPinnedCertificates",
                                    GLib.Variant("(s)", (account,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def pinCertificate(self, account, certificateRaw, local=True):
        """Pin a raw certificate (PEM/DER bytes) for an account (v2.2.0).

        Returns the list of IDs in the pinned certificate chain.
        """
        account = self._valid_account(account)
        if not account: return []
        return self.proxy_confmgr.call_sync("pinCertificate",
                                    GLib.Variant("(sayb)", (account, certificateRaw, local)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def unpinCertificate(self, account, certId):
        """Unpin a certificate from the store (v2.2.0).  Returns True on success."""
        account = self._valid_account(account)
        if not account: return False
        return self.proxy_confmgr.call_sync("unpinCertificate",
                                    GLib.Variant("(ss)", (account, certId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def pinCertificatePath(self, account, certPath):
        """Pin all certificates at the given path for an account (v2.2.0)."""
        account = self._valid_account(account)
        if not account: return
        self.proxy_confmgr.call_sync("pinCertificatePath",
                                    GLib.Variant("(ss)", (account, certPath)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def unpinCertificatePath(self, account, certPath):
        """Unpin all certificates at the given path (v2.2.0).  Returns the count unpinned."""
        account = self._valid_account(account)
        if not account: return 0
        return self.proxy_confmgr.call_sync("unpinCertificatePath",
                                    GLib.Variant("(ss)", (account, certPath)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def pinRemoteCertificate(self, account, certId):
        """Initiate a remote certificate fetch and pin (v2.2.0).  Returns True if started."""
        account = self._valid_account(account)
        if not account: return False
        return self.proxy_confmgr.call_sync("pinRemoteCertificate",
                                    GLib.Variant("(ss)", (account, certId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setCertificateStatus(self, account, certId, status):
        """Set the trust status of a certificate for an account (v2.2.0).

        status: 'UNDEFINED', 'ALLOWED', or 'BANNED'.
        Returns True on success.
        """
        account = self._valid_account(account)
        if not account: return False
        return self.proxy_confmgr.call_sync("setCertificateStatus",
                                    GLib.Variant("(sss)", (account, certId, status)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getCertificatesByStatus(self, account, status):
        """Return the list of certificate IDs having the given status for an account (v2.2.0).

        status: 'ALLOWED' or 'BANNED'.
        """
        account = self._valid_account(account)
        if not account: return []
        return self.proxy_confmgr.call_sync("getCertificatesByStatus",
                                    GLib.Variant("(ss)", (account, status)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getTrustRequests(self, account=None):
        """ """
        account = self._valid_account(account)
        if not account: return
        return self.proxy_confmgr.call_sync("getTrustRequest",
                                            GLib.Variant("(s)", (account,)),
                                            Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def acceptTrustRequest(self, account=None, orig=None):
        """ """
        account = self._valid_account(account)
        if not account: return
        # from is a reserved word
        return self.proxy_confmgr.call_sync("acceptTrustRequest",
                                            GLib.Variant("(ss)", (account, orig,)),
                                            Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def discardTrustRequest(self, account=None, orig=None):
        """ """
        account = self._valid_account(account)
        if not account: return
        return self.proxy_confmgr.call_sync("discardTrustRequest",
                                            GLib.Variant("(ss)", (account, orig,)),
                                            Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def sendTrustRequest(self, account, to, payload):
        """ """
        account = self._valid_account(account)
        if not account or not to or not payload: 
            return
        payload = bytearray(payload.encode('utf_8'))
        self.proxy_confmgr.call_sync("sendTrustRequest",
                                    GLib.Variant("(ssay)", (account, to, payload,)),
                                    Gio.DBusCallFlags.NONE, -1, None)


    def addContact(self, account=None, uri=None):
        """ """
        account = self._valid_account(account)
        if not account: return
        return self.proxy_confmgr.call_sync("addContact",
                                    GLib.Variant("(ss)", (account, uri,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def removeContact(self, account=None, uri=None, ban=False):
        """ """
        account = self._valid_account(account)
        if not account: return
        return self.proxy_confmgr.call_sync("removeContact",
                                    GLib.Variant("(ssb)", (account, uri, ban,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getContactDetails(self, account=None, uri=None):
        """ """
        account = self._valid_account(account)
        if not account: return
        return self.proxy_confmgr.call_sync("getContactDetails",
                                    GLib.Variant("(ss)", (account, uri,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getContacts(self, account=None):
        """ """
        account = self._valid_account(account)
        if not account: return None
        cl = self.proxy_confmgr.call_sync("getContacts",
                                    GLib.Variant("(s)", (account, )),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]
        fresh = {c['id']: c for c in cl}
        self.cachedContactsList.update(fresh)
        return fresh

    def getAddrFromInterfaceName(self, interface):
        """Return the IP address bound to a network interface name."""
        return self.proxy_confmgr.call_sync("getAddrFromInterfaceName",
                                    GLib.Variant("(s)", (interface,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getAllIpInterface(self):
        """Return the list of available IP interface addresses."""
        return self.proxy_confmgr.call_sync("getAllIpInterface",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getAllIpInterfaceByName(self):
        """Return the list of available IP interface names."""
        return self.proxy_confmgr.call_sync("getAllIpInterfaceByName",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def sendFile(self, account, conversationId, filePath, fileDisplayName, replyTo=""):
        """Send a file into a conversation (v10.0.0)."""
        account = self._valid_account(account)
        if not account: return
        self.proxy_confmgr.call_sync("sendFile",
                                    GLib.Variant("(sssss)", (account, conversationId, filePath, fileDisplayName, replyTo)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def fileTransferInfo(self, account, to, fileId):
        """Return transfer info for a file: (error_code, path, totalSize, bytesProgress) (v10.0.0)."""
        account = self._valid_account(account)
        if not account: return None
        return self.proxy_confmgr.call_sync("fileTransferInfo",
                                    GLib.Variant("(sss)", (account, to, fileId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()

    def downloadFile(self, account, conversationId, interactionId, fileId, path):
        """Download a file transfer to path (v10.1.0).  Returns True on success."""
        account = self._valid_account(account)
        if not account: return False
        return self.proxy_confmgr.call_sync("downloadFile",
                                    GLib.Variant("(sssss)", (account, conversationId, interactionId, fileId, path)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def cancelDataTransfer(self, account, to, fileId):
        """Cancel an ongoing data transfer (v10.0.0).  Returns an error code (0 = success)."""
        account = self._valid_account(account)
        if not account: return -1
        return self.proxy_confmgr.call_sync("cancelDataTransfer",
                                    GLib.Variant("(sss)", (account, to, fileId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def monitor(self, continuous):
        """Ask the daemon to dump monitoring info (v10.0.0).

        continuous=True keeps emitting; False dumps once.
        """
        self.proxy_confmgr.call_sync("monitor",
                                    GLib.Variant("(b)", (continuous,)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def getConnectionList(self, account, conversationId=""):
        """Return the list of active ICE/TLS connections for an account (v13.8.0)."""
        account = self._valid_account(account)
        if not account: return []
        return self.proxy_confmgr.call_sync("getConnectionList",
                                    GLib.Variant("(ss)", (account, conversationId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getChannelList(self, account, connectionId):
        """Return the list of channels for a connection (v13.8.0)."""
        account = self._valid_account(account)
        if not account: return []
        return self.proxy_confmgr.call_sync("getChannelList",
                                    GLib.Variant("(ss)", (account, connectionId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def startConversation(self, account=None):
        account = self._valid_account(account)
        if not account: return
        return self.proxy_confmgr.call_sync("startConversation",
                                    GLib.Variant("(s)", (account, )),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def acceptConversationRequest(self, account=None, conversationId=None):
        """Accept a pending conversation request (v10.0.0)."""
        account = self._valid_account(account)
        if not account or not conversationId: return
        self.proxy_confmgr.call_sync("acceptConversationRequest",
                                    GLib.Variant("(ss)", (account, conversationId)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def declineConversationRequest(self, account=None, conversationId=None):
        """Decline a pending conversation request (v10.0.0)."""
        account = self._valid_account(account)
        if not account or not conversationId: return
        self.proxy_confmgr.call_sync("declineConversationRequest",
                                    GLib.Variant("(ss)", (account, conversationId)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def removeConversation(self, account=None, convid=None):
        account = self._valid_account(account)
        if not account: return
        if not convid or convid == "": 
            return False
        return self.proxy_confmgr.call_sync("removeConversation",
                                    GLib.Variant("(ss)", (account, convid )),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getConversations(self, account=None):
        account = self._valid_account(account)
        if not account: return
        return self.proxy_confmgr.call_sync("getConversations",
                                    GLib.Variant("(s)", (account, )),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getActiveCalls(self, account=None, conversationId=None):
        """Return the list of active calls in a conversation (v13.7.0)."""
        account = self._valid_account(account)
        if not account or not conversationId: return []
        return self.proxy_confmgr.call_sync("getActiveCalls",
                                    GLib.Variant("(ss)", (account, conversationId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getConversationRequests(self, account=None):
        """Return the list of pending conversation requests for an account (v10.0.0)."""
        account = self._valid_account(account)
        if not account: return []
        return self.proxy_confmgr.call_sync("getConversationRequests",
                                    GLib.Variant("(s)", (account,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def updateConversationInfos(self, account=None, conversationId=None, infos=None):
        """Update conversation metadata (title, description, avatar) (v10.0.0)."""
        account = self._valid_account(account)
        if not account or not conversationId: return
        self.proxy_confmgr.call_sync("updateConversationInfos",
                                    GLib.Variant("(ssa{ss})", (account, conversationId, infos or {})),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def conversationInfos(self, account=None, convid=None):
        account = self._valid_account(account)
        if not account: return
        if not convid or convid == "": 
            return
        return self.proxy_confmgr.call_sync("conversationInfos",
                                    GLib.Variant("(ss)", (account, convid )),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setConversationPreferences(self, account=None, conversationId=None, prefs=None):
        """Update synced conversation preferences (color, notifications, …) (v13.5.0)."""
        account = self._valid_account(account)
        if not account or not conversationId: return
        self.proxy_confmgr.call_sync("setConversationPreferences",
                                    GLib.Variant("(ssa{ss})", (account, conversationId, prefs or {})),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def getConversationPreferences(self, account=None, conversationId=None):
        """Return the synced preferences dict for a conversation (v13.5.0)."""
        account = self._valid_account(account)
        if not account or not conversationId: return {}
        return self.proxy_confmgr.call_sync("getConversationPreferences",
                                    GLib.Variant("(ss)", (account, conversationId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def addConversationMember(self, account=None, conversationId=None, contactUri=None):
        """Add a contact to a conversation (v10.0.0)."""
        account = self._valid_account(account)
        if not account or not conversationId or not contactUri: return
        self.proxy_confmgr.call_sync("addConversationMember",
                                    GLib.Variant("(sss)", (account, conversationId, contactUri)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def removeConversationMember(self, account=None, conversationId=None, contactUri=None):
        """Remove a contact from a conversation (v10.0.0)."""
        account = self._valid_account(account)
        if not account or not conversationId or not contactUri: return
        self.proxy_confmgr.call_sync("removeConversationMember",
                                    GLib.Variant("(sss)", (account, conversationId, contactUri)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def getConversationMembers(self, account=None, convid=None):
        account = self._valid_account(account)
        if not account: return
        if not convid or convid == "": 
            return
        return self.proxy_confmgr.call_sync("getConversationMembers",
                                    GLib.Variant("(ss)", (account, convid )),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def sendMessage(self, account, conversation, message, commitId, flag):
        account = self._valid_account(account)
        if not account: return
        if not conversation or conversation == "": return
        self.proxy_confmgr.call_sync("sendMessage",
                                    GLib.Variant("(ssssi)", (account, conversation, message, commitId, flag)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def loadConversation(self, account=None, conversationId=None, fromMessage="", n=0):
        """Load up to n messages from conversationId starting at fromMessage (v14.0.0).

        Returns a request ID; results arrive via swarmLoaded signal.
        """
        account = self._valid_account(account)
        if not account or not conversationId: return 0
        return self.proxy_confmgr.call_sync("loadConversation",
                                    GLib.Variant("(sssu)", (account, conversationId, fromMessage, n)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def loadSwarmUntil(self, account=None, conversationId=None, fromMessage="", toMessage=""):
        """Load messages between fromMessage and toMessage (v15.1.0).

        Returns a request ID; results arrive via swarmLoaded signal.
        """
        account = self._valid_account(account)
        if not account or not conversationId: return 0
        return self.proxy_confmgr.call_sync("loadSwarmUntil",
                                    GLib.Variant("(ssss)", (account, conversationId, fromMessage, toMessage)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def countInteractions(self, account=None, conversationId=None, toId="", fromId="", authorUri=""):
        """Count messages between two commit IDs, optionally filtered by author (v10.0.0).

        Returns an unsigned int.
        """
        account = self._valid_account(account)
        if not account or not conversationId: return 0
        return self.proxy_confmgr.call_sync("countInteractions",
                                    GLib.Variant("(sssss)", (account, conversationId, toId, fromId, authorUri)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def clearCache(self, account=None, conversationId=None):
        """Clear cached interactions so the client can reload them (v14.0.0)."""
        account = self._valid_account(account)
        if not account or not conversationId: return
        self.proxy_confmgr.call_sync("clearCache",
                                    GLib.Variant("(ss)", (account, conversationId)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def searchConversation(self, account=None, conversationId="", author="", lastId="",
                           regexSearch="", type_="", after=0, before=0, maxResult=0, flag=0):
        """Search messages in a conversation with optional filters (v13.4.0).

        Returns a search ID; results arrive via messagesFound signal.
        """
        account = self._valid_account(account)
        if not account: return 0
        return self.proxy_confmgr.call_sync("searchConversation",
                                    GLib.Variant("(sssssssxxui)",
                                        (account, conversationId, author, lastId,
                                         regexSearch, type_, after, before, maxResult, flag)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def connectivityChanged(self):
        """Notify the daemon that the network connectivity has changed (v2.3.0)."""
        self.proxy_confmgr.call_sync("connectivityChanged",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None)

    def setDefaultModerator(self, account, peerURI, state):
        """Set or unset a peer as a default moderator for an account (v9.9.0)."""
        account = self._valid_account(account)
        if not account: return
        self.proxy_confmgr.call_sync("setDefaultModerator",
                                    GLib.Variant("(ssb)", (account, peerURI, state)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def getDefaultModerators(self, account=None):
        """Return the list of default moderator URIs for an account (v9.9.0)."""
        account = self._valid_account(account)
        if not account: return []
        return self.proxy_confmgr.call_sync("getDefaultModerators",
                                    GLib.Variant("(s)", (account,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def enableLocalModerators(self, account=None, isModEnabled=True):
        """Enable or disable local moderators for an account (v9.9.0)."""
        account = self._valid_account(account)
        if not account: return
        self.proxy_confmgr.call_sync("enableLocalModerators",
                                    GLib.Variant("(sb)", (account, isModEnabled)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def isLocalModeratorsEnabled(self, account=None):
        """Return True if local moderators are enabled for an account (v9.9.0)."""
        account = self._valid_account(account)
        if not account: return False
        return self.proxy_confmgr.call_sync("isLocalModeratorsEnabled",
                                    GLib.Variant("(s)", (account,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setAllModerators(self, account=None, allModerators=False):
        """Grant moderator role to every participant in the account (v9.10.0)."""
        account = self._valid_account(account)
        if not account: return
        self.proxy_confmgr.call_sync("setAllModerators",
                                    GLib.Variant("(sb)", (account, allModerators)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def isAllModerators(self, account=None):
        """Return True if all participants are moderators for an account (v9.10.0)."""
        account = self._valid_account(account)
        if not account: return False
        return self.proxy_confmgr.call_sync("isAllModerators",
                                    GLib.Variant("(s)", (account,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]


    #
    # Account management
    #

    def _valid_account(self, account):
        account = account or self.account
        if account is None:
            logger.warning("No provided or current account!")
        return account

    def isAccountExists(self, account):
        """ Checks if the account exists"""
        return account in self.getAllAccounts()

    def isAccountEnable(self, account=None):
        """Return True if the account is enabled. If no account is provided, active account is used"""
        return self.getAccountDetails(self._valid_account(account))['Account.enable'] == "true"

    def isAccountRegistered(self, account=None):
        """Return True if the account is registered. If no account is provided, active account is used"""
        return self.getVolatileAccountDetails(self._valid_account(account))['Account.registrationStatus'] in ('READY', 'REGISTERED')

    def isAccountOfType(self, account_type, account=None):
        """Return True if the account type is the given one. If no account is provided, active account is used"""
        return self.getAccountDetails(self._valid_account(account))['Account.type'] == account_type


    def getAllEnabledAccounts(self):
        """Return a list with all enabled-only accounts"""
        return [x for x in self.getAllAccounts() if self.isAccountEnable(x)]

    def getAllRegisteredAccounts(self):
        """Return a list with all registered-only accounts"""
        return [x for x in self.getAllAccounts() if self.isAccountRegistered(x)]

    def setAccountByAlias(self, alias):
        """Define as active the first account who match with the alias"""

        for testedaccount in self.getAllAccounts():
            details = self.getAccountDetails(testedaccount)
            if (details['Account.enable'] == 'true' and
                details['Account.alias'] == alias):
                self.account = testedaccount
                logger.info(f"account is {account}")
                return self.account
        logger.error("No enabled account matched with alias")
        return None

    def getAccountByAlias(self, alias):
        """Get account name having its alias"""
        for account in self.getAllAccounts():
            details = self.getAccountDetails(account)
            if details['Account.alias'] == alias:
                return account
        logger.error("No account matched with alias")
        return None

    def setAccount(self, account):
        """Define the active account

        The active account will be used when sending a new call
        """
        self.account = account if account in self.getAllAccounts() else None
        return self.account

    def setFirstRegisteredAccount(self):
        """Find the first enabled account and define it as active"""
        rAccounts = self.getAllRegisteredAccounts()
        if 0 == len(rAccounts):
            logger.error("No registered account !")
            self.account = None
            return None
        else:
            pass
        return self.setAccount(rAccounts[0])

    def setFirstActiveAccount(self):
        """Find the first enabled account and define it as active"""
        aAccounts = self.getAllEnabledAccounts()
        if 0 == len(aAccounts):
            logger.error("No active account !")
            return None
        return self.setAccount(aAccounts[0])

    def getAccount(self):
        """Return the active account"""
        if not self.account:
            self.setFirstRegisteredAccount()
        #if self.account != "IP2IP" and not self.isAccountRegistered():
        #    raise CtrlAccountError("Unable to place a call without a registered account")
        return self.account

    def setAccountEnable(self, account=None, enable=False):
        """Set account enabled"""
        account = self._valid_account(account)
        if not account: return
        details = self.getAccountDetails(account)
        details['Account.enable'] = enable
        return self.proxy_confmgr.call_sync("setAccountDetails",
                                    GLib.Variant("sa{ss}", (account,details,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setAccountDetails(self, account=None, details=None):
        """Set account details"""
        if details is None:
            logger.error("Must provide some details to update")
            return
        if (type(details) == str):
            d = json.loads(details)
        elif (str(type(details)) == "<class '_io.TextIOWrapper'>"):
            d = json.load(details)
        else:
            logger.error("Provided details are nor a string nor a file descriptor")
            return
        account = self._valid_account(account)
        if not account: return
        odetails = self.getAccountDetails(account)
        for k,v in d:
            if odetails[k] is None:
                logger.error("the key %s is not recognized" % k)
                return
            odetails[k] = v
        return self.proxy_confmgr.call_sync("setAccountDetails",
                                    GLib.Variant("(sa{ss})", (account, odetails,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()

    def setAccountRegistered(self, account=None, register=False):
        """ Tries to register the account"""
        account = self._valid_account(account)
        if not account: return
        return self.proxy_confmgr.call_sync("sendRegister",
                                    GLib.Variant("(sb)", (account, register,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()

    #
    # VideoManager
    #

    def getDeviceList(self):
        """Return the list of detected video device IDs."""
        return self.proxy_videomgr.call_sync("getDeviceList",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getCapabilities(self, deviceId):
        """Return capabilities (channels, sizes, rates) for a video device."""
        return self.proxy_videomgr.call_sync("getCapabilities",
                                    GLib.Variant("(s)", (deviceId,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getSettings(self, deviceId):
        """Return the settings dict for a video device."""
        return self.proxy_videomgr.call_sync("getSettings",
                                    GLib.Variant("(s)", (deviceId,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def applySettings(self, deviceId, settings):
        """Apply a settings dict to a video device."""
        self.proxy_videomgr.call_sync("applySettings",
                                    GLib.Variant("(sa{ss})", (deviceId, settings)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def getDefaultDevice(self):
        """Return the ID of the default video device."""
        return self.proxy_videomgr.call_sync("getDefaultDevice",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setDefaultDevice(self, deviceId):
        """Set the default video device by ID."""
        self.proxy_videomgr.call_sync("setDefaultDevice",
                                    GLib.Variant("(s)", (deviceId,)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def startLocalMediaRecorder(self, videoInputId, filepath):
        """Start a local video/audio recorder (v??).

        filepath is the base path; the daemon appends the extension.
        Returns the final output path (also used as the recorder ID for stopLocalRecorder).
        """
        return self.proxy_videomgr.call_sync("startLocalMediaRecorder",
                                    GLib.Variant("(ss)", (videoInputId, filepath)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def stopLocalRecorder(self, filepath):
        """Stop a local recorder identified by the path returned by startLocalMediaRecorder."""
        self.proxy_videomgr.call_sync("stopLocalRecorder",
                                    GLib.Variant("(s)", (filepath,)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def startAudioDevice(self):
        """Start the audio layer so the device can be read."""
        self.proxy_videomgr.call_sync("startAudioDevice",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None)

    def stopAudioDevice(self):
        """Stop the audio layer."""
        self.proxy_videomgr.call_sync("stopAudioDevice",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None)

    def openVideoInput(self, inputUri):
        """Open a video input by MRL and expose a Sink.

        inputUri formats: 'camera://DEVICE', 'display://NAME[ WxH]', 'file://PATH'.
        Returns the input ID (also the sink ID).
        """
        return self.proxy_videomgr.call_sync("openVideoInput",
                                    GLib.Variant("(s)", (inputUri,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def closeVideoInput(self, inputId):
        """Close a video input by ID.  Returns True if closed."""
        return self.proxy_videomgr.call_sync("closeVideoInput",
                                    GLib.Variant("(s)", (inputId,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getDecodingAccelerated(self):
        """Return True if hardware video decoding is enabled."""
        return self.proxy_videomgr.call_sync("getDecodingAccelerated",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setDecodingAccelerated(self, state):
        """Enable (True) or disable (False) hardware video decoding."""
        self.proxy_videomgr.call_sync("setDecodingAccelerated",
                                    GLib.Variant("(b)", (state,)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def getEncodingAccelerated(self):
        """Return True if hardware video encoding is enabled."""
        return self.proxy_videomgr.call_sync("getEncodingAccelerated",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setEncodingAccelerated(self, state):
        """Enable (True) or disable (False) hardware video encoding."""
        self.proxy_videomgr.call_sync("setEncodingAccelerated",
                                    GLib.Variant("(b)", (state,)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def setDeviceOrientation(self, deviceId, angle):
        """Set the device orientation in degrees (counterclockwise)."""
        self.proxy_videomgr.call_sync("setDeviceOrientation",
                                    GLib.Variant("(si)", (deviceId, angle)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def getRenderer(self, callId):
        """Return a dict of renderer info for a call (empty strings / '0' if not found)."""
        return self.proxy_videomgr.call_sync("getRenderer",
                                    GLib.Variant("(s)", (callId,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def startShmSink(self, sinkId, value):
        """Start (True) or stop (False) shared-memory transfer for a sink."""
        self.proxy_videomgr.call_sync("startShmSink",
                                    GLib.Variant("(sb)", (sinkId, value)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def createMediaPlayer(self, path):
        """Create a media player for the file at path (v13.10.0).  Returns the player ID."""
        return self.proxy_videomgr.call_sync("createMediaPlayer",
                                    GLib.Variant("(s)", (path,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def closeMediaPlayer(self, player_id):
        """Close a media player (v13.10.0).  Returns True on success."""
        return self.proxy_videomgr.call_sync("closeMediaPlayer",
                                    GLib.Variant("(s)", (player_id,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def pausePlayer(self, player_id, pause):
        """Pause (True) or resume (False) a media player (v13.10.0).  Returns True on success."""
        return self.proxy_videomgr.call_sync("pausePlayer",
                                    GLib.Variant("(sb)", (player_id, pause)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def mutePlayerAudio(self, player_id, mute):
        """Mute (True) or unmute (False) a media player's audio (v13.10.0).  Returns True on success."""
        return self.proxy_videomgr.call_sync("mutePlayerAudio",
                                    GLib.Variant("(sb)", (player_id, mute)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def playerSeekToTime(self, player_id, time):
        """Seek a media player to a timestamp (v13.10.0).  Returns True on success."""
        return self.proxy_videomgr.call_sync("playerSeekToTime",
                                    GLib.Variant("(si)", (player_id, time)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getPlayerPosition(self, player_id):
        """Return the current playback position timestamp of a media player (v13.10.0)."""
        return self.proxy_videomgr.call_sync("getPlayerPosition",
                                    GLib.Variant("(s)", (player_id,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getPlayerDuration(self, player_id):
        """Return the total duration timestamp of a media player (v13.10.0)."""
        return self.proxy_videomgr.call_sync("getPlayerDuration",
                                    GLib.Variant("(s)", (player_id,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setAutoRestart(self, player_id, restart):
        """Configure a media player to loop automatically (v13.10.0)."""
        self.proxy_videomgr.call_sync("setAutoRestart",
                                    GLib.Variant("(sb)", (player_id, restart)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    #
    # PresenceManager
    #

    def publish(self, accountId=None, status=True, note=""):
        """ publish presence (boolean) with a note for other users
        """
        account = self._valid_account(accountId)
        if not account: return
        return self.proxy_presmgr.call_sync("publish",
                                    GLib.Variant("(sbs)", (account, status, note,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def answerServerRequest(self, buddyUri="", flag=False):
        """Answer a presence request from the server
        """
        if buddyUri != "":
            return self.proxy_presmgr.call_sync("answerServerRequest",
                                    GLib.Variant("(sb)", (buddyUri, flag, )),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def subscribeBuddy(self, account=None, buddyUri="", flag=True):
        """Ask be be notified when 'uri' presence change
        """
        account = self._valid_account(account)
        if not account: return
        if buddyUri != "":
            self.buddyUriList[buddyUri] = -1
            return self.proxy_presmgr.call_sync("subscribeBuddy",
                                    GLib.Variant("(ssb)", (account, buddyUri, flag, )),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()

    def getSubscriptions(self, accountId=None, credentialInformation=None):
        """New clients connecting to existing daemon need to be aware of active
                subscriptions.

            While there is more status than "Online" or "Offline", only those

            List of hashes map with the following key-value pairs:
                    * Buddy:      URI of the contact
                    * Status:     "Online" or "Offline"
                    * LineStatus: String
        """
        account = self._valid_account(accountId)
        if not account: return
        return self.proxy_presmgr.call_sync("getSubscriptions",
                                    GLib.Variant("(ss)", (account, credentialInformation or "", )),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setSubscriptions(self, accountId=None, uriList=[], invalidUris=[]):
        """Calling "subscribeBuddy" in a loop is too slow

           A list of SIP URIs

           List of invalid URIs. An URI must be a valid SIP URI. Clients should purge
                   the list from all invalid URIs
        """
        account = self._valid_account(accountId)
        if not account: return
        # self.buddyUriList.keys()
        # self.invalidBuddyUris
        return self.proxy_presmgr.call_sync("setSubscriptions",
                                    GLib.Variant("(sasas)", (account, uriList, invalidUris,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    #
    # iPluginManagerInterface
    #

    def loadPlugin(self, path):
        """Load a plugin from path (v9.2.0).  Returns True on success."""
        return self.proxy_plugins.call_sync("loadPlugin",
                                    GLib.Variant("(s)", (path,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def unloadPlugin(self, path):
        """Unload a plugin by path (v9.2.0).  Returns True on success."""
        return self.proxy_plugins.call_sync("unloadPlugin",
                                    GLib.Variant("(s)", (path,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getPluginDetails(self, path):
        """Return a details dict for a plugin at path (v9.2.0)."""
        return self.proxy_plugins.call_sync("getPluginDetails",
                                    GLib.Variant("(s)", (path,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getPluginPreferences(self, path, accountId=""):
        """Return the list of preference descriptors for a plugin (v11.1.0)."""
        return self.proxy_plugins.call_sync("getPluginPreferences",
                                    GLib.Variant("(ss)", (path, accountId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setPluginPreference(self, path, accountId, key, value):
        """Set a plugin preference value (v9.2.0).  Returns True on success."""
        return self.proxy_plugins.call_sync("setPluginPreference",
                                    GLib.Variant("(ssss)", (path, accountId, key, value)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getPluginPreferencesValues(self, path, accountId=""):
        """Return the current preference values dict for a plugin (v9.2.0)."""
        return self.proxy_plugins.call_sync("getPluginPreferencesValues",
                                    GLib.Variant("(ss)", (path, accountId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def resetPluginPreferencesValues(self, path, accountId=""):
        """Reset all preference values for a plugin to defaults (v9.2.0).  Returns True on success."""
        return self.proxy_plugins.call_sync("resetPluginPreferencesValues",
                                    GLib.Variant("(ss)", (path, accountId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getInstalledPlugins(self):
        """Return the list of installed plugin paths (v9.9.0)."""
        return self.proxy_plugins.call_sync("getInstalledPlugins",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getLoadedPlugins(self):
        """Return the list of currently loaded plugin paths (v9.9.0)."""
        return self.proxy_plugins.call_sync("getLoadedPlugins",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def installPlugin(self, jplPath, force=False):
        """Install a plugin from a .jpl archive (v9.2.0).  Returns an int status code."""
        return self.proxy_plugins.call_sync("installPlugin",
                                    GLib.Variant("(sb)", (jplPath, force)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def uninstallPlugin(self, pluginRootPath):
        """Uninstall a plugin by its root path (v9.2.0).  Returns an int status code."""
        return self.proxy_plugins.call_sync("uninstallPlugin",
                                    GLib.Variant("(s)", (pluginRootPath,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getPlatformInfo(self):
        """Return a dict of platform information (v13.9.0)."""
        return self.proxy_plugins.call_sync("getPlatformInfo",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getCallMediaHandlers(self):
        """Return the list of registered call-media handler IDs (v9.9.0)."""
        return self.proxy_plugins.call_sync("getCallMediaHandlers",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getChatHandlers(self):
        """Return the list of registered chat handler IDs (v9.9.0)."""
        return self.proxy_plugins.call_sync("getChatHandlers",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def toggleCallMediaHandler(self, mediaHandlerId, callId, toggle):
        """Enable (True) or disable (False) a call-media handler for a call (v9.2.0)."""
        self.proxy_plugins.call_sync("toggleCallMediaHandler",
                                    GLib.Variant("(ssb)", (mediaHandlerId, callId, toggle)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def toggleChatHandler(self, chatHandlerId, accountId, peerId, toggle):
        """Enable (True) or disable (False) a chat handler for a peer (v9.9.0)."""
        self.proxy_plugins.call_sync("toggleChatHandler",
                                    GLib.Variant("(sssb)", (chatHandlerId, accountId, peerId, toggle)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def getCallMediaHandlerDetails(self, mediaHandlerId):
        """Return the details dict of a call-media handler (v9.2.0)."""
        return self.proxy_plugins.call_sync("getCallMediaHandlerDetails",
                                    GLib.Variant("(s)", (mediaHandlerId,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getCallMediaHandlerStatus(self, callId):
        """Return the list of active call-media handler IDs for a call (v9.3.0)."""
        return self.proxy_plugins.call_sync("getCallMediaHandlerStatus",
                                    GLib.Variant("(s)", (callId,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getChatHandlerDetails(self, chatHandlerId):
        """Return the details dict of a chat handler (v9.9.0)."""
        return self.proxy_plugins.call_sync("getChatHandlerDetails",
                                    GLib.Variant("(s)", (chatHandlerId,)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getChatHandlerStatus(self, accountId, peerId):
        """Return the list of active chat handler IDs for a peer (v9.9.0)."""
        return self.proxy_plugins.call_sync("getChatHandlerStatus",
                                    GLib.Variant("(ss)", (accountId, peerId)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def getPluginsEnabled(self):
        """Return True if the plugin system is enabled (v9.3.0)."""
        return self.proxy_plugins.call_sync("getPluginsEnabled",
                                    None,
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def setPluginsEnabled(self, state):
        """Enable (True) or disable (False) the plugin system (v9.3.0)."""
        self.proxy_plugins.call_sync("setPluginsEnabled",
                                    GLib.Variant("(b)", (state,)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def sendWebViewMessage(self, pluginId, webViewId, messageId, payload):
        """Send a message from a client webview to a plugin (v13.2.0)."""
        self.proxy_plugins.call_sync("sendWebViewMessage",
                                    GLib.Variant("(ssss)", (pluginId, webViewId, messageId, payload)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    def sendWebViewAttach(self, pluginId, accountId, webViewId, action):
        """Notify a plugin that a webview was created (v13.2.0).

        Returns a relative path to an HTML file inside the plugin's datapath.
        """
        return self.proxy_plugins.call_sync("sendWebViewAttach",
                                    GLib.Variant("(ssss)", (pluginId, accountId, webViewId, action)),
                                    Gio.DBusCallFlags.NONE, -1, None).unpack()[0]

    def sendWebViewDetach(self, pluginId, webViewId):
        """Notify a plugin that a webview was destroyed (v13.2.0)."""
        self.proxy_plugins.call_sync("sendWebViewDetach",
                                    GLib.Variant("(ss)", (pluginId, webViewId)),
                                    Gio.DBusCallFlags.NONE, -1, None)

    #
    # Helper functions
    #

    def _GenerateCallID(self):
        """Generate Call ID"""
        m = hashlib.md5()
        t = int( time.time() * 1000 )
        r = int( random.random()*100000000000000000 )
        m.update(str(t) + str(r))
        callId = m.hexdigest()
        return callId

    def _on_daemon_status(self, *args):
        """
        monitor, status, msg):
            pass
        Handle monitor status changes.
        """
        try:
            monitor = args[0]
            status = args[1]
            msg = args[2]
            if status == "connected":
                self.bus = monitor.bus
                self.register()
            if status == "offline" or status == "error":
                self.bus = None
                self.unregister()
                self.account = None
            if status != self._last_daemon_status:
                self._last_daemon_status = status
                self.emit('daemon-connection-status', status, msg)
        except Exception as e:
            logger.error(f"[Manager] monitor status error: {e}")

    def _get_proxy(self, interface):
        """Create a DBus proxy for a given interface."""
        try:
            path = DBUS_DEAMON_PATH + "/" + interface
            objet = DBUS_DEAMON_OBJECT + "." + interface
            return Gio.DBusProxy.new_sync(
                self.bus, Gio.DBusProxyFlags.NONE, None,
                DBUS_DEAMON_OBJECT, path, objet, None)
        except Exception as e:
            logger.error(f"Proxy Init Error ({interface}): {e}")
            return None

    def __del__(self):
        self.unregister()

    def isRegistered(self):
        return self.registered
    
    def printClientCallList(self):
        for call in self.activeCalls:
            pass

