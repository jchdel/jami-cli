#!/usr/bin/env bash
set -euo pipefail

REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="$REPO/build"
JOBS="${JOBS:-$(nproc)}"
CLEAN=0

usage() {
    cat <<EOF
Usage: $0 [--clean] [--jobs N]

  --clean    wipe build/ and reconfigure from scratch
  --jobs N   parallel jobs (default: nproc=$JOBS)
  JOBS=N     same as --jobs via environment
EOF
    exit 1
}

while [[ $# -gt 0 ]]; do
    case $1 in
        --clean)  CLEAN=1; shift ;;
        --jobs)   JOBS=$2; shift 2 ;;
        -h|--help) usage ;;
        *) echo "Unknown option: $1"; usage ;;
    esac
done

cd "$REPO"

if [[ $CLEAN -eq 1 ]]; then
    echo "--- clean: removing $BUILD_DIR"
    rm -rf "$BUILD_DIR"
fi

# CMake configure
if [[ ! -f "$BUILD_DIR/CMakeCache.txt" ]]; then
    echo "--- cmake configure"
    cmake -B "$BUILD_DIR" -S "$REPO" -DJAMI_DBUS=ON
fi

# Build
echo "--- cmake build (jamid, -j$JOBS)"
cmake --build "$BUILD_DIR" --target jamid -j"$JOBS"

# Debian package
echo "--- dpkg-buildpackage"
dpkg-buildpackage -b --no-sign

echo ""
ls -1 "$REPO/../"jami-daemon_*.deb \
       "$REPO/../"python3-libjami_*.deb \
       "$REPO/../"python3-jamictrl_*.deb 2>/dev/null \
    | sed 's/^/Package ready: /'
